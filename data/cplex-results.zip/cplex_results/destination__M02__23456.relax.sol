<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__23456.mps"
   objectiveValue="-676692.16673460521"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="24"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145390.77590964147"
   maxSlack="1"
   maxRedCost="100268.65781237563"
   kappa="25.714285714285715"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-676692.1667346051"/>
 </objectiveValues>
</CPLEXSolution>
