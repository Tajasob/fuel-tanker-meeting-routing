<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__89012.mps"
   objectiveValue="-458.79215752578421"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="856"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="1.1368683772161603e-13"
   maxX="1"
   maxPi="3810.5219874818158"
   maxSlack="1"
   maxRedCost="4342.997746877686"
   kappa="239350.85714285716"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-458.79215752578421"/>
 </objectiveValues>
</CPLEXSolution>
