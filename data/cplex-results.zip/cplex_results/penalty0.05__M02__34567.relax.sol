<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__34567.mps"
   objectiveValue="-34248.330152728515"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="4993"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.7284841053187847e-12"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="5142.1536499559516"
   maxSlack="1"
   maxRedCost="7951.8881955528914"
   kappa="128771.51515151515"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-34248.330152728515"/>
 </objectiveValues>
</CPLEXSolution>
