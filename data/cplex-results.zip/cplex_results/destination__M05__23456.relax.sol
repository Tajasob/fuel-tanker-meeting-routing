<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__23456.mps"
   objectiveValue="-1162669.9260500681"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="32"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145312.4928242949"
   maxSlack="1"
   maxRedCost="149948.76870510352"
   kappa="25"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1162669.9260500681"/>
 </objectiveValues>
</CPLEXSolution>
