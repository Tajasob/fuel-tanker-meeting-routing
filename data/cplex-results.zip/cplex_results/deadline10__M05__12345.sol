<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1413440.687150632"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="94"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x24" index="24" value="1"/>
  <variable name="x3935" index="3935" value="1"/>
  <variable name="x7480" index="7480" value="1"/>
  <variable name="x11087" index="11087" value="1"/>
  <variable name="x17540" index="17540" value="1"/>
  <variable name="x19009" index="19009" value="1"/>
  <variable name="x23374" index="23374" value="1"/>
  <variable name="x26372" index="26372" value="1"/>
  <variable name="x123744" index="123744" value="1"/>
  <variable name="x402923" index="402923" value="1"/>
  <variable name="x453924" index="453924" value="1"/>
  <variable name="x514451" index="514451" value="1"/>
  <variable name="x749311" index="749311" value="1"/>
  <variable name="x772480" index="772480" value="1"/>
  <variable name="x810057" index="810057" value="1"/>
  <variable name="x1014244" index="1014244" value="1"/>
  <variable name="x1136427" index="1136427" value="1"/>
  <variable name="x1153658" index="1153658" value="1"/>
  <variable name="x1271122" index="1271122" value="1"/>
  <variable name="x1285265" index="1285265" value="1"/>
  <variable name="x1342145" index="1342145" value="1"/>
  <variable name="x1358191" index="1358191" value="1"/>
  <variable name="x1417746" index="1417746" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1413440.687150632"/>
 </objectiveValues>
</CPLEXSolution>
