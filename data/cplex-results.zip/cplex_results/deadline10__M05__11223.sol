<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1513557.8686172091"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="9629"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2875" index="2875" value="1"/>
  <variable name="x2984" index="2984" value="1"/>
  <variable name="x8232" index="8232" value="1"/>
  <variable name="x10059" index="10059" value="1"/>
  <variable name="x11542" index="11542" value="1"/>
  <variable name="x15259" index="15259" value="1"/>
  <variable name="x17310" index="17310" value="1"/>
  <variable name="x20238" index="20238" value="1"/>
  <variable name="x37538" index="37538" value="1"/>
  <variable name="x46398" index="46398" value="1"/>
  <variable name="x357662" index="357662" value="1"/>
  <variable name="x531749" index="531749" value="1"/>
  <variable name="x621995" index="621995" value="1"/>
  <variable name="x727464" index="727464" value="1"/>
  <variable name="x809491" index="809491" value="1"/>
  <variable name="x1008450" index="1008450" value="1"/>
  <variable name="x1202626" index="1202626" value="1"/>
  <variable name="x1353170" index="1353170" value="1"/>
  <variable name="x1615157" index="1615157" value="1"/>
  <variable name="x1632667" index="1632667" value="1"/>
  <variable name="x1640348" index="1640348" value="1"/>
  <variable name="x1822313" index="1822313" value="1"/>
  <variable name="x1870936" index="1870936" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1513557.8686172091"/>
 </objectiveValues>
</CPLEXSolution>
