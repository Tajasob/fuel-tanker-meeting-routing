<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__89012.mps"
   objectiveValue="-777047.24602560059"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="440"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="7.2759576141834259e-12"
   maxX="1"
   maxPi="145400.5760164157"
   maxSlack="1"
   maxRedCost="149876.32384833012"
   kappa="3527.9999999999995"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-777047.24602560047"/>
 </objectiveValues>
</CPLEXSolution>
