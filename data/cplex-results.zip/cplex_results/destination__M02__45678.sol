<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-527299.85417288064"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="13"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x0" index="0" value="1"/>
  <variable name="x18" index="18" value="1"/>
  <variable name="x31" index="31" value="1"/>
  <variable name="x58" index="58" value="1"/>
  <variable name="x77" index="77" value="1"/>
  <variable name="x87" index="87" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-527299.85417288064"/>
 </objectiveValues>
</CPLEXSolution>
