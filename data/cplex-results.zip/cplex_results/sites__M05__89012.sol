<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1217660.7699110757"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="970"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x76" index="76" value="1"/>
  <variable name="x440" index="440" value="1"/>
  <variable name="x995" index="995" value="1"/>
  <variable name="x1848" index="1848" value="1"/>
  <variable name="x2348" index="2348" value="1"/>
  <variable name="x2774" index="2774" value="1"/>
  <variable name="x3518" index="3518" value="1"/>
  <variable name="x12849" index="12849" value="1"/>
  <variable name="x15052" index="15052" value="1"/>
  <variable name="x15861" index="15861" value="1"/>
  <variable name="x17072" index="17072" value="1"/>
  <variable name="x19121" index="19121" value="1"/>
  <variable name="x26673" index="26673" value="1"/>
  <variable name="x27308" index="27308" value="1"/>
  <variable name="x43077" index="43077" value="1"/>
  <variable name="x48116" index="48116" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1217660.7699110757"/>
 </objectiveValues>
</CPLEXSolution>
