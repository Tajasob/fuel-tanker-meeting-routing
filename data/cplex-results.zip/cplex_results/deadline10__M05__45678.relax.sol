<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__45678.mps"
   objectiveValue="-1463714.8596241907"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="19728"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="3.637978807091713e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="149482.57567174878"
   maxSlack="1"
   maxRedCost="150542.59531931949"
   kappa="69459.627906976748"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1463714.8596241905"/>
 </objectiveValues>
</CPLEXSolution>
