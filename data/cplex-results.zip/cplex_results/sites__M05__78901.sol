<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1412682.5299361264"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1222"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x61" index="61" value="1"/>
  <variable name="x548" index="548" value="1"/>
  <variable name="x1068" index="1068" value="1"/>
  <variable name="x1502" index="1502" value="1"/>
  <variable name="x1939" index="1939" value="1"/>
  <variable name="x2386" index="2386" value="1"/>
  <variable name="x2633" index="2633" value="1"/>
  <variable name="x2996" index="2996" value="1"/>
  <variable name="x7055" index="7055" value="1"/>
  <variable name="x14051" index="14051" value="1"/>
  <variable name="x15079" index="15079" value="1"/>
  <variable name="x20889" index="20889" value="1"/>
  <variable name="x24601" index="24601" value="1"/>
  <variable name="x26607" index="26607" value="1"/>
  <variable name="x36703" index="36703" value="1"/>
  <variable name="x37253" index="37253" value="1"/>
  <variable name="x39344" index="39344" value="1"/>
  <variable name="x46956" index="46956" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1412682.5299361262"/>
 </objectiveValues>
</CPLEXSolution>
