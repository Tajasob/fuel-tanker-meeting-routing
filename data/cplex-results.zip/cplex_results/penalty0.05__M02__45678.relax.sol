<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__45678.mps"
   objectiveValue="-23426.009378305913"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7659"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.8189894035458565e-12"
   maxPrimalResidual="0"
   maxDualResidual="6.8212102632969618e-13"
   maxX="1"
   maxPi="6077.1302978873755"
   maxSlack="1"
   maxRedCost="6381.5795506441173"
   kappa="84434.98000000001"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-23426.009378305913"/>
 </objectiveValues>
</CPLEXSolution>
