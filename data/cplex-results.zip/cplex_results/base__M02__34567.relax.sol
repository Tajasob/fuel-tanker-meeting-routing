<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__34567.mps"
   objectiveValue="-1126748.3301527286"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="13512"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.8207660913467407e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145654.91926515612"
   maxSlack="1"
   maxRedCost="150477.1649346718"
   kappa="341673.62068965519"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1126748.3301527286"/>
 </objectiveValues>
</CPLEXSolution>
