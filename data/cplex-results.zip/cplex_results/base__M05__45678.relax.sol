<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__45678.mps"
   objectiveValue="-1763151.1384331221"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="47916"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="6.5483618527650833e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195399.99669521835"
   maxSlack="1"
   maxRedCost="200163.37771573311"
   kappa="844860.69387755101"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1763151.1384331221"/>
 </objectiveValues>
</CPLEXSolution>
