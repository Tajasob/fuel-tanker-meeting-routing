<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-921.12065276173018"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1429"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x7553" index="7553" value="1"/>
  <variable name="x9386" index="9386" value="1"/>
  <variable name="x153943" index="153943" value="1"/>
  <variable name="x451293" index="451293" value="1"/>
  <variable name="x464494" index="464494" value="1"/>
  <variable name="x966504" index="966504" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-921.12065276173018"/>
 </objectiveValues>
</CPLEXSolution>
