<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__89012.mps"
   objectiveValue="-1268195.8323236255"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="6081"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="3.637978807091713e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="195493.42287976306"
   maxSlack="1"
   maxRedCost="200148.36440791495"
   kappa="219471.56756756757"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1268195.8323236255"/>
 </objectiveValues>
</CPLEXSolution>
