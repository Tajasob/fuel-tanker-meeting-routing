<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-977434.23242071399"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3942"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x590" index="590" value="1"/>
  <variable name="x4915" index="4915" value="1"/>
  <variable name="x5369" index="5369" value="1"/>
  <variable name="x8905" index="8905" value="1"/>
  <variable name="x9235" index="9235" value="1"/>
  <variable name="x238015" index="238015" value="1"/>
  <variable name="x362554" index="362554" value="1"/>
  <variable name="x429340" index="429340" value="1"/>
  <variable name="x502651" index="502651" value="1"/>
  <variable name="x526953" index="526953" value="1"/>
  <variable name="x720866" index="720866" value="1"/>
  <variable name="x819567" index="819567" value="1"/>
  <variable name="x938922" index="938922" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-977434.23242071387"/>
 </objectiveValues>
</CPLEXSolution>
