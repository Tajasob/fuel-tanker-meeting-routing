<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__67890.mps"
   objectiveValue="-1617969.4490392013"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="35535"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.8207660913467407e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195571.11891712414"
   maxSlack="1"
   maxRedCost="200602.41608611611"
   kappa="335674.97142857144"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1617969.4490392008"/>
 </objectiveValues>
</CPLEXSolution>
