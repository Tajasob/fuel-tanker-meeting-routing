<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__34567.mps"
   objectiveValue="-1261601.6707447148"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="39"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99560.176908769019"
   maxSlack="1"
   maxRedCost="100208.02008946192"
   kappa="52.92307692307692"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1261601.6707447148"/>
 </objectiveValues>
</CPLEXSolution>
