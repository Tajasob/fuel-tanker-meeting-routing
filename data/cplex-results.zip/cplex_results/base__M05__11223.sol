<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1912853.1297990547"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="10373"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x105" index="105" value="1"/>
  <variable name="x4616" index="4616" value="1"/>
  <variable name="x11380" index="11380" value="1"/>
  <variable name="x15376" index="15376" value="1"/>
  <variable name="x17595" index="17595" value="1"/>
  <variable name="x25636" index="25636" value="1"/>
  <variable name="x26660" index="26660" value="1"/>
  <variable name="x30341" index="30341" value="1"/>
  <variable name="x50178" index="50178" value="1"/>
  <variable name="x59038" index="59038" value="1"/>
  <variable name="x307156" index="307156" value="1"/>
  <variable name="x432977" index="432977" value="1"/>
  <variable name="x440086" index="440086" value="1"/>
  <variable name="x874046" index="874046" value="1"/>
  <variable name="x1282061" index="1282061" value="1"/>
  <variable name="x1475727" index="1475727" value="1"/>
  <variable name="x1639509" index="1639509" value="1"/>
  <variable name="x1714326" index="1714326" value="1"/>
  <variable name="x1910210" index="1910210" value="1"/>
  <variable name="x2267369" index="2267369" value="1"/>
  <variable name="x2415083" index="2415083" value="1"/>
  <variable name="x2562574" index="2562574" value="1"/>
  <variable name="x2582810" index="2582810" value="1"/>
  <variable name="x2640954" index="2640954" value="1"/>
  <variable name="x2998850" index="2998850" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1912853.1297990545"/>
 </objectiveValues>
</CPLEXSolution>
