<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__12345.mps"
   objectiveValue="-626785.14829504408"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="20"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145269.70758470311"
   maxSlack="1"
   maxRedCost="100246.15767701733"
   kappa="13.285714285714286"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-626785.1482950442"/>
 </objectiveValues>
</CPLEXSolution>
