<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-2770.5946618716889"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1758"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x5039" index="5039" value="1"/>
  <variable name="x7666" index="7666" value="1"/>
  <variable name="x310215" index="310215" value="1"/>
  <variable name="x316466" index="316466" value="1"/>
  <variable name="x436319" index="436319" value="1"/>
  <variable name="x867842" index="867842" value="1"/>
  <variable name="x1210885" index="1210885" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-2770.5946618716889"/>
 </objectiveValues>
</CPLEXSolution>
