<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-877280.20860615827"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2016"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x141" index="141" value="1"/>
  <variable name="x2706" index="2706" value="1"/>
  <variable name="x4979" index="4979" value="1"/>
  <variable name="x7504" index="7504" value="1"/>
  <variable name="x9599" index="9599" value="1"/>
  <variable name="x51754" index="51754" value="1"/>
  <variable name="x129460" index="129460" value="1"/>
  <variable name="x152860" index="152860" value="1"/>
  <variable name="x175638" index="175638" value="1"/>
  <variable name="x321044" index="321044" value="1"/>
  <variable name="x479477" index="479477" value="1"/>
  <variable name="x535988" index="535988" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-877280.20860615827"/>
 </objectiveValues>
</CPLEXSolution>
