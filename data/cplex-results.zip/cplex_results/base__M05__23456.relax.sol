<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__23456.mps"
   objectiveValue="-1813194.3878146624"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="49685"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.0186340659856796e-10"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="220438.77265542949"
   maxSlack="1"
   maxRedCost="225167.45472204895"
   kappa="279473.61702127667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1813194.3878146624"/>
 </objectiveValues>
</CPLEXSolution>
