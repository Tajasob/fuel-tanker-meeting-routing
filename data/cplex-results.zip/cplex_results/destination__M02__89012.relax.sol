<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__89012.mps"
   objectiveValue="-527048.02908083179"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="6"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95541.34775534799"
   maxSlack="1"
   maxRedCost="50426.491159124373"
   kappa="3.6000000000000001"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-527048.02908083179"/>
 </objectiveValues>
</CPLEXSolution>
