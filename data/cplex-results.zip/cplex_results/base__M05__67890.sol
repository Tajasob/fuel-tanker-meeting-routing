<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1617969.449039201"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="7936"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3740" index="3740" value="1"/>
  <variable name="x4564" index="4564" value="1"/>
  <variable name="x8535" index="8535" value="1"/>
  <variable name="x11459" index="11459" value="1"/>
  <variable name="x18965" index="18965" value="1"/>
  <variable name="x19647" index="19647" value="1"/>
  <variable name="x22708" index="22708" value="1"/>
  <variable name="x31825" index="31825" value="1"/>
  <variable name="x251984" index="251984" value="1"/>
  <variable name="x587731" index="587731" value="1"/>
  <variable name="x619388" index="619388" value="1"/>
  <variable name="x778118" index="778118" value="1"/>
  <variable name="x843266" index="843266" value="1"/>
  <variable name="x883006" index="883006" value="1"/>
  <variable name="x1257641" index="1257641" value="1"/>
  <variable name="x1330152" index="1330152" value="1"/>
  <variable name="x1496908" index="1496908" value="1"/>
  <variable name="x1613216" index="1613216" value="1"/>
  <variable name="x1929556" index="1929556" value="1"/>
  <variable name="x2053972" index="2053972" value="1"/>
  <variable name="x2341563" index="2341563" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1617969.449039201"/>
 </objectiveValues>
</CPLEXSolution>
