<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__56789.mps"
   objectiveValue="-1363190.3118678366"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="287"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="7.2759576141834259e-12"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145419.02680483818"
   maxSlack="1"
   maxRedCost="150138.49525648664"
   kappa="1073.4285714285716"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1363190.3118678369"/>
 </objectiveValues>
</CPLEXSolution>
