<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-2825.794716508859"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1543"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2266" index="2266" value="1"/>
  <variable name="x3801" index="3801" value="1"/>
  <variable name="x94403" index="94403" value="1"/>
  <variable name="x177655" index="177655" value="1"/>
  <variable name="x367108" index="367108" value="1"/>
  <variable name="x392366" index="392366" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-2825.794716508859"/>
 </objectiveValues>
</CPLEXSolution>
