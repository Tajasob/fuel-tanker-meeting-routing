<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__56789.mps"
   objectiveValue="-1813423.253956557"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="45507"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="8.7311491370201111e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195514.95199425699"
   maxSlack="1"
   maxRedCost="200214.04072349664"
   kappa="940223.36065573769"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1813423.253956557"/>
 </objectiveValues>
</CPLEXSolution>
