<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-620236.08524545608"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x3" index="3" value="1"/>
  <variable name="x14" index="14" value="1"/>
  <variable name="x25" index="25" value="1"/>
  <variable name="x46" index="46" value="1"/>
  <variable name="x50" index="50" value="1"/>
  <variable name="x53" index="53" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-620236.08524545608"/>
 </objectiveValues>
</CPLEXSolution>
