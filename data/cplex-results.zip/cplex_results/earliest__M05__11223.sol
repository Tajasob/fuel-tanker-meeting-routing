<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-616167.6055384957"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x9" index="9" value="1"/>
  <variable name="x23" index="23" value="1"/>
  <variable name="x24" index="24" value="1"/>
  <variable name="x31" index="31" value="1"/>
  <variable name="x39" index="39" value="1"/>
  <variable name="x40" index="40" value="1"/>
  <variable name="x48" index="48" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-616167.6055384957"/>
 </objectiveValues>
</CPLEXSolution>
