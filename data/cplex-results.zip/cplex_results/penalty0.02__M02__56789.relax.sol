<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__56789.mps"
   objectiveValue="-921.12065276173018"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1089"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.5474735088646412e-13"
   maxPrimalResidual="0"
   maxDualResidual="2.2737367544323206e-13"
   maxX="1"
   maxPi="3525.1633928136616"
   maxSlack="1"
   maxRedCost="3904.4728758923466"
   kappa="972893.53846153838"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-921.12065276173018"/>
 </objectiveValues>
</CPLEXSolution>
