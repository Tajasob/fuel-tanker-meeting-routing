<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1863415.2932926337"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2935"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3223" index="3223" value="1"/>
  <variable name="x5265" index="5265" value="1"/>
  <variable name="x9624" index="9624" value="1"/>
  <variable name="x15829" index="15829" value="1"/>
  <variable name="x18187" index="18187" value="1"/>
  <variable name="x24197" index="24197" value="1"/>
  <variable name="x29969" index="29969" value="1"/>
  <variable name="x34619" index="34619" value="1"/>
  <variable name="x562562" index="562562" value="1"/>
  <variable name="x609644" index="609644" value="1"/>
  <variable name="x814030" index="814030" value="1"/>
  <variable name="x1069138" index="1069138" value="1"/>
  <variable name="x1100539" index="1100539" value="1"/>
  <variable name="x1114017" index="1114017" value="1"/>
  <variable name="x1202348" index="1202348" value="1"/>
  <variable name="x1286806" index="1286806" value="1"/>
  <variable name="x1456643" index="1456643" value="1"/>
  <variable name="x1492879" index="1492879" value="1"/>
  <variable name="x1683153" index="1683153" value="1"/>
  <variable name="x1727698" index="1727698" value="1"/>
  <variable name="x1802234" index="1802234" value="1"/>
  <variable name="x1847085" index="1847085" value="1"/>
  <variable name="x1921468" index="1921468" value="1"/>
  <variable name="x1943960" index="1943960" value="1"/>
  <variable name="x2103159" index="2103159" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1863415.2932926337"/>
 </objectiveValues>
</CPLEXSolution>
