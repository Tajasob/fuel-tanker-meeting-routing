<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__12345.mps"
   objectiveValue="-240874.74465957109"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="11"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99562.930203159864"
   maxSlack="1"
   maxRedCost="100074.20125966419"
   kappa="59.399999999999999"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-240874.74465957104"/>
 </objectiveValues>
</CPLEXSolution>
