<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__11223.mps"
   objectiveValue="-428704.24310238159"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95840.27638571008"
   maxSlack="1"
   maxRedCost="50208.163473951332"
   kappa="2.6666666666666665"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-428704.24310238153"/>
 </objectiveValues>
</CPLEXSolution>
