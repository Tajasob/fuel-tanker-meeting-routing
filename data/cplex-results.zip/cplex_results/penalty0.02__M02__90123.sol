<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1416.7966292424435"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1260"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x10048" index="10048" value="1"/>
  <variable name="x36685" index="36685" value="1"/>
  <variable name="x210797" index="210797" value="1"/>
  <variable name="x326121" index="326121" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1416.7966292424435"/>
 </objectiveValues>
</CPLEXSolution>
