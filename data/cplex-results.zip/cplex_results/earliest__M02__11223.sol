<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-428704.24310238153"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x11" index="11" value="1"/>
  <variable name="x12" index="12" value="1"/>
  <variable name="x14" index="14" value="1"/>
  <variable name="x30" index="30" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-428704.24310238153"/>
 </objectiveValues>
</CPLEXSolution>
