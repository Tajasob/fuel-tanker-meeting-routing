<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__11223.mps"
   objectiveValue="-1211573.6452814252"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="84"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="99693.94707478465"
   maxSlack="1"
   maxRedCost="100237.1839549471"
   kappa="129.23076923076923"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1211573.6452814252"/>
 </objectiveValues>
</CPLEXSolution>
