<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__67890.mps"
   objectiveValue="-627272.70351209491"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="4855"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145785.79403613842"
   maxSlack="1"
   maxRedCost="150375.36758029702"
   kappa="201939.62962962961"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-627272.70351209491"/>
 </objectiveValues>
</CPLEXSolution>
