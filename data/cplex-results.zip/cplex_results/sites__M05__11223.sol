<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1512520.6848793779"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="859"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x41" index="41" value="1"/>
  <variable name="x687" index="687" value="1"/>
  <variable name="x1722" index="1722" value="1"/>
  <variable name="x1989" index="1989" value="1"/>
  <variable name="x2243" index="2243" value="1"/>
  <variable name="x3326" index="3326" value="1"/>
  <variable name="x3570" index="3570" value="1"/>
  <variable name="x4101" index="4101" value="1"/>
  <variable name="x4687" index="4687" value="1"/>
  <variable name="x9473" index="9473" value="1"/>
  <variable name="x17610" index="17610" value="1"/>
  <variable name="x20462" index="20462" value="1"/>
  <variable name="x29603" index="29603" value="1"/>
  <variable name="x30954" index="30954" value="1"/>
  <variable name="x39223" index="39223" value="1"/>
  <variable name="x45799" index="45799" value="1"/>
  <variable name="x45889" index="45889" value="1"/>
  <variable name="x46639" index="46639" value="1"/>
  <variable name="x48858" index="48858" value="1"/>
  <variable name="x48995" index="48995" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1512520.6848793779"/>
 </objectiveValues>
</CPLEXSolution>
