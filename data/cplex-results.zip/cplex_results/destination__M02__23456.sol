<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-676692.1667346051"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="12"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x0" index="0" value="1"/>
  <variable name="x12" index="12" value="1"/>
  <variable name="x36" index="36" value="1"/>
  <variable name="x49" index="49" value="1"/>
  <variable name="x78" index="78" value="1"/>
  <variable name="x89" index="89" value="1"/>
  <variable name="x93" index="93" value="1"/>
  <variable name="x96" index="96" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-676692.1667346051"/>
 </objectiveValues>
</CPLEXSolution>
