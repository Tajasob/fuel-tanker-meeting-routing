<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1267.8971590831275"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1338"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x9931" index="9931" value="1"/>
  <variable name="x261103" index="261103" value="1"/>
  <variable name="x417688" index="417688" value="1"/>
  <variable name="x589555" index="589555" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1267.8971590831275"/>
 </objectiveValues>
</CPLEXSolution>
