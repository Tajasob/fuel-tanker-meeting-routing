<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-32152.788613661472"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1809"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x4" index="4" value="1"/>
  <variable name="x2272" index="2272" value="1"/>
  <variable name="x3801" index="3801" value="1"/>
  <variable name="x6380" index="6380" value="1"/>
  <variable name="x9449" index="9449" value="1"/>
  <variable name="x19409" index="19409" value="1"/>
  <variable name="x94719" index="94719" value="1"/>
  <variable name="x152797" index="152797" value="1"/>
  <variable name="x178225" index="178225" value="1"/>
  <variable name="x367612" index="367612" value="1"/>
  <variable name="x392370" index="392370" value="1"/>
  <variable name="x405528" index="405528" value="1"/>
  <variable name="x479087" index="479087" value="1"/>
  <variable name="x525961" index="525961" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-32152.788613661472"/>
 </objectiveValues>
</CPLEXSolution>
