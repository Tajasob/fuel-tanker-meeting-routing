<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1213609.8018092732"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="455"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x223" index="223" value="1"/>
  <variable name="x944" index="944" value="1"/>
  <variable name="x1339" index="1339" value="1"/>
  <variable name="x1946" index="1946" value="1"/>
  <variable name="x2825" index="2825" value="1"/>
  <variable name="x2933" index="2933" value="1"/>
  <variable name="x3111" index="3111" value="1"/>
  <variable name="x3521" index="3521" value="1"/>
  <variable name="x3899" index="3899" value="1"/>
  <variable name="x5528" index="5528" value="1"/>
  <variable name="x6313" index="6313" value="1"/>
  <variable name="x7609" index="7609" value="1"/>
  <variable name="x8078" index="8078" value="1"/>
  <variable name="x10095" index="10095" value="1"/>
  <variable name="x11159" index="11159" value="1"/>
  <variable name="x12326" index="12326" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1213609.8018092732"/>
 </objectiveValues>
</CPLEXSolution>
