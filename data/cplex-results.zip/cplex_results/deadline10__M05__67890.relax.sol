<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__67890.mps"
   objectiveValue="-1368323.6758438929"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7302"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="8.7311491370201111e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="195382.32022598968"
   maxSlack="1"
   maxRedCost="199459.58443567704"
   kappa="544625.04000000004"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1368323.6758438933"/>
 </objectiveValues>
</CPLEXSolution>
