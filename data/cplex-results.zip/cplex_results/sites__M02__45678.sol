<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-727111.85220666695"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="511"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x101" index="101" value="1"/>
  <variable name="x283" index="283" value="1"/>
  <variable name="x496" index="496" value="1"/>
  <variable name="x969" index="969" value="1"/>
  <variable name="x1416" index="1416" value="1"/>
  <variable name="x6631" index="6631" value="1"/>
  <variable name="x11949" index="11949" value="1"/>
  <variable name="x12126" index="12126" value="1"/>
  <variable name="x12415" index="12415" value="1"/>
  <variable name="x13838" index="13838" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-727111.85220666684"/>
 </objectiveValues>
</CPLEXSolution>
