<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__90123.mps"
   objectiveValue="-24867.266887177386"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="3194"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.3642420526593924e-12"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="7434.9669315575611"
   maxSlack="1"
   maxRedCost="10211.656077868302"
   kappa="83912"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-24867.266887177386"/>
 </objectiveValues>
</CPLEXSolution>
