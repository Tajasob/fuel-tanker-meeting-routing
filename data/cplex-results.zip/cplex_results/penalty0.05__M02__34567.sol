<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-34248.330152728515"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="35"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x255" index="255" value="1"/>
  <variable name="x2349" index="2349" value="1"/>
  <variable name="x3311" index="3311" value="1"/>
  <variable name="x8310" index="8310" value="1"/>
  <variable name="x10672" index="10672" value="1"/>
  <variable name="x89598" index="89598" value="1"/>
  <variable name="x113942" index="113942" value="1"/>
  <variable name="x131197" index="131197" value="1"/>
  <variable name="x394836" index="394836" value="1"/>
  <variable name="x545796" index="545796" value="1"/>
  <variable name="x561828" index="561828" value="1"/>
  <variable name="x585374" index="585374" value="1"/>
  <variable name="x732979" index="732979" value="1"/>
  <variable name="x788569" index="788569" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-34248.330152728515"/>
 </objectiveValues>
</CPLEXSolution>
