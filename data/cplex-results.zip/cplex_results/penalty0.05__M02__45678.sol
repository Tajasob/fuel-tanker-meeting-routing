<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-22399.334139222708"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2372"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1077" index="1077" value="1"/>
  <variable name="x3043" index="3043" value="1"/>
  <variable name="x3644" index="3644" value="1"/>
  <variable name="x6864" index="6864" value="1"/>
  <variable name="x9929" index="9929" value="1"/>
  <variable name="x101447" index="101447" value="1"/>
  <variable name="x237302" index="237302" value="1"/>
  <variable name="x261835" index="261835" value="1"/>
  <variable name="x447455" index="447455" value="1"/>
  <variable name="x450747" index="450747" value="1"/>
  <variable name="x500435" index="500435" value="1"/>
  <variable name="x543840" index="543840" value="1"/>
  <variable name="x583953" index="583953" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-22399.334139222705"/>
 </objectiveValues>
</CPLEXSolution>
