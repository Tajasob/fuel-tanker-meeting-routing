<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-626532.57169620402"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="19"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x13" index="13" value="1"/>
  <variable name="x40" index="40" value="1"/>
  <variable name="x63" index="63" value="1"/>
  <variable name="x74" index="74" value="1"/>
  <variable name="x100" index="100" value="1"/>
  <variable name="x101" index="101" value="1"/>
  <variable name="x102" index="102" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-626532.57169620402"/>
 </objectiveValues>
</CPLEXSolution>
