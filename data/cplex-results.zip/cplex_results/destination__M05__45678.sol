<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1112269.6580554768"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="56"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x22" index="22" value="1"/>
  <variable name="x64" index="64" value="1"/>
  <variable name="x107" index="107" value="1"/>
  <variable name="x131" index="131" value="1"/>
  <variable name="x162" index="162" value="1"/>
  <variable name="x182" index="182" value="1"/>
  <variable name="x217" index="217" value="1"/>
  <variable name="x239" index="239" value="1"/>
  <variable name="x252" index="252" value="1"/>
  <variable name="x264" index="264" value="1"/>
  <variable name="x272" index="272" value="1"/>
  <variable name="x273" index="273" value="1"/>
  <variable name="x279" index="279" value="1"/>
  <variable name="x295" index="295" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1112269.6580554768"/>
 </objectiveValues>
</CPLEXSolution>
