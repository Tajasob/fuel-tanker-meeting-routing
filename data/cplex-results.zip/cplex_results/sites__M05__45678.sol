<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1462983.5460036003"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="952"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x51" index="51" value="1"/>
  <variable name="x227" index="227" value="1"/>
  <variable name="x929" index="929" value="1"/>
  <variable name="x1557" index="1557" value="1"/>
  <variable name="x1993" index="1993" value="1"/>
  <variable name="x2302" index="2302" value="1"/>
  <variable name="x2400" index="2400" value="1"/>
  <variable name="x3023" index="3023" value="1"/>
  <variable name="x3911" index="3911" value="1"/>
  <variable name="x4386" index="4386" value="1"/>
  <variable name="x7192" index="7192" value="1"/>
  <variable name="x10779" index="10779" value="1"/>
  <variable name="x16921" index="16921" value="1"/>
  <variable name="x19808" index="19808" value="1"/>
  <variable name="x20300" index="20300" value="1"/>
  <variable name="x21934" index="21934" value="1"/>
  <variable name="x31773" index="31773" value="1"/>
  <variable name="x39082" index="39082" value="1"/>
  <variable name="x39474" index="39474" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1462983.5460036003"/>
 </objectiveValues>
</CPLEXSolution>
