<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__45678.mps"
   objectiveValue="-1267.897159083127"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1673"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="9.0949470177292824e-13"
   maxPrimalResidual="0"
   maxDualResidual="2.2737367544323206e-13"
   maxX="1"
   maxPi="3448.5808478982626"
   maxSlack="1"
   maxRedCost="4424.4502443712754"
   kappa="178598.28571428571"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1267.897159083127"/>
 </objectiveValues>
</CPLEXSolution>
