<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-727455.69023467915"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1278"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x105" index="105" value="1"/>
  <variable name="x1323" index="1323" value="1"/>
  <variable name="x2341" index="2341" value="1"/>
  <variable name="x3882" index="3882" value="1"/>
  <variable name="x5424" index="5424" value="1"/>
  <variable name="x26892" index="26892" value="1"/>
  <variable name="x55250" index="55250" value="1"/>
  <variable name="x64338" index="64338" value="1"/>
  <variable name="x107433" index="107433" value="1"/>
  <variable name="x147379" index="147379" value="1"/>
  <variable name="x206353" index="206353" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-727455.69023467915"/>
 </objectiveValues>
</CPLEXSolution>
