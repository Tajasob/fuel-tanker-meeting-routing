<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__89012.mps"
   objectiveValue="-22280.208606158147"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1740"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.8189894035458565e-12"
   maxPrimalResidual="0"
   maxDualResidual="9.0949470177292824e-13"
   maxX="1"
   maxPi="9769.7560416032502"
   maxSlack="1"
   maxRedCost="12222.619357350108"
   kappa="192650.18181818182"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-22280.208606158147"/>
 </objectiveValues>
</CPLEXSolution>
