<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1167183.3562986131"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="25"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x25" index="25" value="1"/>
  <variable name="x37" index="37" value="1"/>
  <variable name="x57" index="57" value="1"/>
  <variable name="x92" index="92" value="1"/>
  <variable name="x129" index="129" value="1"/>
  <variable name="x137" index="137" value="1"/>
  <variable name="x162" index="162" value="1"/>
  <variable name="x191" index="191" value="1"/>
  <variable name="x197" index="197" value="1"/>
  <variable name="x207" index="207" value="1"/>
  <variable name="x213" index="213" value="1"/>
  <variable name="x218" index="218" value="1"/>
  <variable name="x222" index="222" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1167183.3562986131"/>
 </objectiveValues>
</CPLEXSolution>
