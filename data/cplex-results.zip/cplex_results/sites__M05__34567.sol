<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1362412.404366812"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="392"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x172" index="172" value="1"/>
  <variable name="x688" index="688" value="1"/>
  <variable name="x1093" index="1093" value="1"/>
  <variable name="x1308" index="1308" value="1"/>
  <variable name="x2238" index="2238" value="1"/>
  <variable name="x2744" index="2744" value="1"/>
  <variable name="x3205" index="3205" value="1"/>
  <variable name="x3545" index="3545" value="1"/>
  <variable name="x6464" index="6464" value="1"/>
  <variable name="x11172" index="11172" value="1"/>
  <variable name="x11696" index="11696" value="1"/>
  <variable name="x13520" index="13520" value="1"/>
  <variable name="x14041" index="14041" value="1"/>
  <variable name="x15512" index="15512" value="1"/>
  <variable name="x16080" index="16080" value="1"/>
  <variable name="x18704" index="18704" value="1"/>
  <variable name="x19429" index="19429" value="1"/>
  <variable name="x23539" index="23539" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1362412.404366812"/>
 </objectiveValues>
</CPLEXSolution>
