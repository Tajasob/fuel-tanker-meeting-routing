<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-27434.232420713884"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3675"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x590" index="590" value="1"/>
  <variable name="x4915" index="4915" value="1"/>
  <variable name="x5369" index="5369" value="1"/>
  <variable name="x8905" index="8905" value="1"/>
  <variable name="x9230" index="9230" value="1"/>
  <variable name="x237259" index="237259" value="1"/>
  <variable name="x363286" index="363286" value="1"/>
  <variable name="x429340" index="429340" value="1"/>
  <variable name="x502651" index="502651" value="1"/>
  <variable name="x526878" index="526878" value="1"/>
  <variable name="x720878" index="720878" value="1"/>
  <variable name="x819566" index="819566" value="1"/>
  <variable name="x938897" index="938897" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-27434.232420713881"/>
 </objectiveValues>
</CPLEXSolution>
