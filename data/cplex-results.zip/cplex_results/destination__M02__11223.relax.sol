<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__11223.mps"
   objectiveValue="-726382.47382479312"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="28"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145084.45796333082"
   maxSlack="1"
   maxRedCost="100141.04418732801"
   kappa="57.222222222222221"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-726382.47382479301"/>
 </objectiveValues>
</CPLEXSolution>
