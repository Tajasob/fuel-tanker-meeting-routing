<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__89012.mps"
   objectiveValue="-1617538.0675399022"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="30643"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.1641532182693481e-10"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="245350.18390328507"
   maxSlack="1"
   maxRedCost="249833.87575845185"
   kappa="367870.625"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1617538.0675399019"/>
 </objectiveValues>
</CPLEXSolution>
