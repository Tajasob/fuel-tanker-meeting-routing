<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__78901.mps"
   objectiveValue="-1212141.8423489863"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="80"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145163.58268359673"
   maxSlack="1"
   maxRedCost="100206.21197412649"
   kappa="97.090909090909093"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1212141.8423489858"/>
 </objectiveValues>
</CPLEXSolution>
