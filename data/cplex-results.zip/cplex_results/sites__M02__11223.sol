<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-826985.71252694807"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="742"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x231" index="231" value="1"/>
  <variable name="x363" index="363" value="1"/>
  <variable name="x821" index="821" value="1"/>
  <variable name="x1246" index="1246" value="1"/>
  <variable name="x1539" index="1539" value="1"/>
  <variable name="x10358" index="10358" value="1"/>
  <variable name="x11712" index="11712" value="1"/>
  <variable name="x12107" index="12107" value="1"/>
  <variable name="x12272" index="12272" value="1"/>
  <variable name="x17677" index="17677" value="1"/>
  <variable name="x20933" index="20933" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-826985.71252694807"/>
 </objectiveValues>
</CPLEXSolution>
