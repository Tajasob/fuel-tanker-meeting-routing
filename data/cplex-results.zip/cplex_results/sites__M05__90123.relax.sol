<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__90123.mps"
   objectiveValue="-1213609.8018092732"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="397"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="7.2759576141834259e-12"
   maxX="1"
   maxPi="195448.72902574361"
   maxSlack="1"
   maxRedCost="150358.73503929973"
   kappa="12227.181818181818"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1213609.8018092732"/>
 </objectiveValues>
</CPLEXSolution>
