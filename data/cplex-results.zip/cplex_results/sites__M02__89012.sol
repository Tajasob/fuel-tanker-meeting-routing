<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-777047.24602560047"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="157"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x0" index="0" value="1"/>
  <variable name="x323" index="323" value="1"/>
  <variable name="x614" index="614" value="1"/>
  <variable name="x1024" index="1024" value="1"/>
  <variable name="x1093" index="1093" value="1"/>
  <variable name="x1503" index="1503" value="1"/>
  <variable name="x4827" index="4827" value="1"/>
  <variable name="x5639" index="5639" value="1"/>
  <variable name="x6521" index="6521" value="1"/>
  <variable name="x6983" index="6983" value="1"/>
  <variable name="x12249" index="12249" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-777047.24602560047"/>
 </objectiveValues>
</CPLEXSolution>
