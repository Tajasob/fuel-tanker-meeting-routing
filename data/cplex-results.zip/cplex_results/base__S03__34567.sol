<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-290672.26922601258"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x197" index="197" value="1"/>
  <variable name="x627" index="627" value="1"/>
  <variable name="x910" index="910" value="1"/>
  <variable name="x4056" index="4056" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-290672.26922601252"/>
 </objectiveValues>
</CPLEXSolution>
