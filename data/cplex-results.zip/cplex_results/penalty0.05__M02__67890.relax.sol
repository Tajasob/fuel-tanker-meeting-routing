<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__67890.mps"
   objectiveValue="-27052.635347569201"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="5972"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.7284841053187847e-12"
   maxPrimalResidual="0"
   maxDualResidual="9.0949470177292824e-13"
   maxX="1"
   maxPi="7468.2303021513453"
   maxSlack="1"
   maxRedCost="10465.180960179223"
   kappa="150740"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-27052.635347569201"/>
 </objectiveValues>
</CPLEXSolution>
