<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-27052.635347569201"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2333"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x613" index="613" value="1"/>
  <variable name="x2074" index="2074" value="1"/>
  <variable name="x3043" index="3043" value="1"/>
  <variable name="x5039" index="5039" value="1"/>
  <variable name="x7717" index="7717" value="1"/>
  <variable name="x281878" index="281878" value="1"/>
  <variable name="x316475" index="316475" value="1"/>
  <variable name="x436634" index="436634" value="1"/>
  <variable name="x755033" index="755033" value="1"/>
  <variable name="x867842" index="867842" value="1"/>
  <variable name="x873897" index="873897" value="1"/>
  <variable name="x1071051" index="1071051" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-27052.635347569201"/>
 </objectiveValues>
</CPLEXSolution>
