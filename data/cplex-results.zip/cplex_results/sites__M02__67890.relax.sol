<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__67890.mps"
   objectiveValue="-876521.17504835268"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="270"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="7.2759576141834259e-12"
   maxX="1"
   maxPi="195443.16482857338"
   maxSlack="1"
   maxRedCost="200231.10981252906"
   kappa="712.44444444444434"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-876521.17504835268"/>
 </objectiveValues>
</CPLEXSolution>
