<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1077152.7886136617"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3123"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2" index="2" value="1"/>
  <variable name="x2263" index="2263" value="1"/>
  <variable name="x3800" index="3800" value="1"/>
  <variable name="x6380" index="6380" value="1"/>
  <variable name="x9450" index="9450" value="1"/>
  <variable name="x19372" index="19372" value="1"/>
  <variable name="x94403" index="94403" value="1"/>
  <variable name="x152827" index="152827" value="1"/>
  <variable name="x178225" index="178225" value="1"/>
  <variable name="x366865" index="366865" value="1"/>
  <variable name="x392201" index="392201" value="1"/>
  <variable name="x405583" index="405583" value="1"/>
  <variable name="x479089" index="479089" value="1"/>
  <variable name="x526040" index="526040" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1077152.7886136614"/>
 </objectiveValues>
</CPLEXSolution>
