<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__56789.mps"
   objectiveValue="-1413898.4093412526"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="15549"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="3.637978807091713e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195526.54088577686"
   maxSlack="1"
   maxRedCost="200198.93841998573"
   kappa="174184.29729729731"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1413898.4093412526"/>
 </objectiveValues>
</CPLEXSolution>
