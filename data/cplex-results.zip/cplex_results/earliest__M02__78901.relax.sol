<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__78901.mps"
   objectiveValue="-332966.1647416398"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95845.155846216265"
   maxSlack="1"
   maxRedCost="50192.080413845535"
   kappa="2.6666666666666665"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-332966.1647416398"/>
 </objectiveValues>
</CPLEXSolution>
