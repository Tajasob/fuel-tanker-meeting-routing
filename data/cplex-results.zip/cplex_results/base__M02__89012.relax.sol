<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__89012.mps"
   objectiveValue="-877280.20860615803"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1429"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="195536.51623528861"
   maxSlack="1"
   maxRedCost="200216.75682802551"
   kappa="110023.11111111111"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-877280.20860615815"/>
 </objectiveValues>
</CPLEXSolution>
