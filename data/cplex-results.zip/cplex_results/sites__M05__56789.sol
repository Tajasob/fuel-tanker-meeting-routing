<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1363190.3118678369"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="322"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x346" index="346" value="1"/>
  <variable name="x678" index="678" value="1"/>
  <variable name="x1223" index="1223" value="1"/>
  <variable name="x1737" index="1737" value="1"/>
  <variable name="x2335" index="2335" value="1"/>
  <variable name="x3094" index="3094" value="1"/>
  <variable name="x3237" index="3237" value="1"/>
  <variable name="x3487" index="3487" value="1"/>
  <variable name="x5880" index="5880" value="1"/>
  <variable name="x6276" index="6276" value="1"/>
  <variable name="x8347" index="8347" value="1"/>
  <variable name="x8463" index="8463" value="1"/>
  <variable name="x8562" index="8562" value="1"/>
  <variable name="x10269" index="10269" value="1"/>
  <variable name="x11621" index="11621" value="1"/>
  <variable name="x12932" index="12932" value="1"/>
  <variable name="x13325" index="13325" value="1"/>
  <variable name="x16191" index="16191" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1363190.3118678369"/>
 </objectiveValues>
</CPLEXSolution>
