<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__90123.mps"
   objectiveValue="-1688741.118157933"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="11324"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="7.2759576141834259e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195497.03401279179"
   maxSlack="1"
   maxRedCost="200165.21557697997"
   kappa="232562.25641025644"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1688741.1181579328"/>
 </objectiveValues>
</CPLEXSolution>
