<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__11223.mps"
   objectiveValue="-1543168.6968560491"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="36259"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.8207660913467407e-11"
   maxPrimalResidual="1.1102230246251565e-16"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="175403.88755990565"
   maxSlack="1"
   maxRedCost="180284.26346214578"
   kappa="659424.1338028186"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1543168.6968560491"/>
 </objectiveValues>
</CPLEXSolution>
