<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1363480.2166945967"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1179"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x285" index="285" value="1"/>
  <variable name="x909" index="909" value="1"/>
  <variable name="x1716" index="1716" value="1"/>
  <variable name="x2501" index="2501" value="1"/>
  <variable name="x3050" index="3050" value="1"/>
  <variable name="x4048" index="4048" value="1"/>
  <variable name="x4920" index="4920" value="1"/>
  <variable name="x5758" index="5758" value="1"/>
  <variable name="x7270" index="7270" value="1"/>
  <variable name="x15979" index="15979" value="1"/>
  <variable name="x20646" index="20646" value="1"/>
  <variable name="x23823" index="23823" value="1"/>
  <variable name="x30024" index="30024" value="1"/>
  <variable name="x33561" index="33561" value="1"/>
  <variable name="x33597" index="33597" value="1"/>
  <variable name="x38601" index="38601" value="1"/>
  <variable name="x45994" index="45994" value="1"/>
  <variable name="x49262" index="49262" value="1"/>
  <variable name="x49954" index="49954" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1363480.2166945967"/>
 </objectiveValues>
</CPLEXSolution>
