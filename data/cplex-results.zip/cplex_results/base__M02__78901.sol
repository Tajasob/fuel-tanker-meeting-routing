<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-976875.61116573634"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="4774"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x896" index="896" value="1"/>
  <variable name="x1200" index="1200" value="1"/>
  <variable name="x5084" index="5084" value="1"/>
  <variable name="x8909" index="8909" value="1"/>
  <variable name="x12218" index="12218" value="1"/>
  <variable name="x18002" index="18002" value="1"/>
  <variable name="x122892" index="122892" value="1"/>
  <variable name="x159461" index="159461" value="1"/>
  <variable name="x294899" index="294899" value="1"/>
  <variable name="x529918" index="529918" value="1"/>
  <variable name="x667030" index="667030" value="1"/>
  <variable name="x787324" index="787324" value="1"/>
  <variable name="x840368" index="840368" value="1"/>
  <variable name="x841276" index="841276" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-976875.61116573634"/>
 </objectiveValues>
</CPLEXSolution>
