<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__34567.mps"
   objectiveValue="-1712881.7507451063"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="36202"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="6.5483618527650833e-11"
   maxPrimalResidual="0"
   maxDualResidual="4.3655745685100555e-11"
   maxX="1"
   maxPi="195702.11249584952"
   maxSlack="1"
   maxRedCost="200543.9163867796"
   kappa="506814.25925925927"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1712881.750745106"/>
 </objectiveValues>
</CPLEXSolution>
