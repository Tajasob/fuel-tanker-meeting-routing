<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__34567.mps"
   objectiveValue="-775750.72897936194"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="27"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99555.81678578326"
   maxSlack="1"
   maxRedCost="100150.95734104792"
   kappa="34.285714285714285"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-775750.72897936206"/>
 </objectiveValues>
</CPLEXSolution>
