<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1863442.775757673"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="8099"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2214" index="2214" value="1"/>
  <variable name="x5265" index="5265" value="1"/>
  <variable name="x10025" index="10025" value="1"/>
  <variable name="x12182" index="12182" value="1"/>
  <variable name="x21726" index="21726" value="1"/>
  <variable name="x25983" index="25983" value="1"/>
  <variable name="x27969" index="27969" value="1"/>
  <variable name="x31226" index="31226" value="1"/>
  <variable name="x270043" index="270043" value="1"/>
  <variable name="x457278" index="457278" value="1"/>
  <variable name="x642028" index="642028" value="1"/>
  <variable name="x700538" index="700538" value="1"/>
  <variable name="x735017" index="735017" value="1"/>
  <variable name="x773661" index="773661" value="1"/>
  <variable name="x889081" index="889081" value="1"/>
  <variable name="x970686" index="970686" value="1"/>
  <variable name="x1105311" index="1105311" value="1"/>
  <variable name="x1160437" index="1160437" value="1"/>
  <variable name="x1391904" index="1391904" value="1"/>
  <variable name="x1715242" index="1715242" value="1"/>
  <variable name="x2036645" index="2036645" value="1"/>
  <variable name="x2245006" index="2245006" value="1"/>
  <variable name="x2431980" index="2431980" value="1"/>
  <variable name="x2559273" index="2559273" value="1"/>
  <variable name="x2833979" index="2833979" value="1"/>
  <variable name="x3155214" index="3155214" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1863442.775757673"/>
 </objectiveValues>
</CPLEXSolution>
