<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1763151.1384331218"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="73"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x655" index="655" value="1"/>
  <variable name="x2233" index="2233" value="1"/>
  <variable name="x7142" index="7142" value="1"/>
  <variable name="x10306" index="10306" value="1"/>
  <variable name="x18208" index="18208" value="1"/>
  <variable name="x21178" index="21178" value="1"/>
  <variable name="x23135" index="23135" value="1"/>
  <variable name="x29336" index="29336" value="1"/>
  <variable name="x62387" index="62387" value="1"/>
  <variable name="x120775" index="120775" value="1"/>
  <variable name="x913265" index="913265" value="1"/>
  <variable name="x955104" index="955104" value="1"/>
  <variable name="x1188768" index="1188768" value="1"/>
  <variable name="x1309296" index="1309296" value="1"/>
  <variable name="x1414025" index="1414025" value="1"/>
  <variable name="x1631536" index="1631536" value="1"/>
  <variable name="x1759828" index="1759828" value="1"/>
  <variable name="x1807043" index="1807043" value="1"/>
  <variable name="x2288958" index="2288958" value="1"/>
  <variable name="x2555991" index="2555991" value="1"/>
  <variable name="x2608361" index="2608361" value="1"/>
  <variable name="x2671006" index="2671006" value="1"/>
  <variable name="x2847512" index="2847512" value="1"/>
  <variable name="x2886006" index="2886006" value="1"/>
  <variable name="x2924642" index="2924642" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1763151.1384331218"/>
 </objectiveValues>
</CPLEXSolution>
