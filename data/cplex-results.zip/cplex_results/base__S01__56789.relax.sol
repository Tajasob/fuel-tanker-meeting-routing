<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__56789.mps"
   objectiveValue="-191180.12449483515"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95656.592526284629"
   maxSlack="1"
   maxRedCost="50449.340128533331"
   kappa="4.666666666666667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-191180.12449483515"/>
 </objectiveValues>
</CPLEXSolution>
