<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-776118.12093501864"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="263"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x13" index="13" value="1"/>
  <variable name="x195" index="195" value="1"/>
  <variable name="x268" index="268" value="1"/>
  <variable name="x705" index="705" value="1"/>
  <variable name="x954" index="954" value="1"/>
  <variable name="x1311" index="1311" value="1"/>
  <variable name="x1448" index="1448" value="1"/>
  <variable name="x3968" index="3968" value="1"/>
  <variable name="x4386" index="4386" value="1"/>
  <variable name="x5047" index="5047" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-776118.12093501864"/>
 </objectiveValues>
</CPLEXSolution>
