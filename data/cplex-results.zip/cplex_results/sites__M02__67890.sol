<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-876521.17504835257"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="302"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x26" index="26" value="1"/>
  <variable name="x201" index="201" value="1"/>
  <variable name="x423" index="423" value="1"/>
  <variable name="x645" index="645" value="1"/>
  <variable name="x991" index="991" value="1"/>
  <variable name="x4293" index="4293" value="1"/>
  <variable name="x6760" index="6760" value="1"/>
  <variable name="x8807" index="8807" value="1"/>
  <variable name="x10195" index="10195" value="1"/>
  <variable name="x10385" index="10385" value="1"/>
  <variable name="x11470" index="11470" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-876521.17504835257"/>
 </objectiveValues>
</CPLEXSolution>
