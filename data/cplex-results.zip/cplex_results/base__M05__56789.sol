<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1813423.2539565575"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="79"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3686" index="3686" value="1"/>
  <variable name="x5311" index="5311" value="1"/>
  <variable name="x9626" index="9626" value="1"/>
  <variable name="x14526" index="14526" value="1"/>
  <variable name="x18084" index="18084" value="1"/>
  <variable name="x23574" index="23574" value="1"/>
  <variable name="x26067" index="26067" value="1"/>
  <variable name="x27819" index="27819" value="1"/>
  <variable name="x35997" index="35997" value="1"/>
  <variable name="x59773" index="59773" value="1"/>
  <variable name="x157261" index="157261" value="1"/>
  <variable name="x301656" index="301656" value="1"/>
  <variable name="x440236" index="440236" value="1"/>
  <variable name="x518423" index="518423" value="1"/>
  <variable name="x733663" index="733663" value="1"/>
  <variable name="x780448" index="780448" value="1"/>
  <variable name="x863125" index="863125" value="1"/>
  <variable name="x865521" index="865521" value="1"/>
  <variable name="x1133404" index="1133404" value="1"/>
  <variable name="x1359457" index="1359457" value="1"/>
  <variable name="x1605727" index="1605727" value="1"/>
  <variable name="x1707184" index="1707184" value="1"/>
  <variable name="x1986122" index="1986122" value="1"/>
  <variable name="x2107237" index="2107237" value="1"/>
  <variable name="x2143000" index="2143000" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1813423.2539565575"/>
 </objectiveValues>
</CPLEXSolution>
