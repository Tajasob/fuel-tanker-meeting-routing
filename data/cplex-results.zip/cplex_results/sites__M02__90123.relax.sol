<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__90123.mps"
   objectiveValue="-826708.27146151382"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="673"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145569.00892964628"
   maxSlack="1"
   maxRedCost="150108.70123550048"
   kappa="5978.666666666667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-826708.27146151394"/>
 </objectiveValues>
</CPLEXSolution>
