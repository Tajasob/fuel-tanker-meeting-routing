<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1211573.6452814252"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="55"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x48" index="48" value="1"/>
  <variable name="x90" index="90" value="1"/>
  <variable name="x122" index="122" value="1"/>
  <variable name="x129" index="129" value="1"/>
  <variable name="x176" index="176" value="1"/>
  <variable name="x204" index="204" value="1"/>
  <variable name="x234" index="234" value="1"/>
  <variable name="x251" index="251" value="1"/>
  <variable name="x264" index="264" value="1"/>
  <variable name="x281" index="281" value="1"/>
  <variable name="x284" index="284" value="1"/>
  <variable name="x290" index="290" value="1"/>
  <variable name="x293" index="293" value="1"/>
  <variable name="x294" index="294" value="1"/>
  <variable name="x300" index="300" value="1"/>
  <variable name="x312" index="312" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1211573.6452814252"/>
 </objectiveValues>
</CPLEXSolution>
