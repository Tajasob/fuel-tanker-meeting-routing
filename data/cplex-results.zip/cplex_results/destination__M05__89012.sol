<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-917609.18870756542"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="24"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x8" index="8" value="1"/>
  <variable name="x38" index="38" value="1"/>
  <variable name="x66" index="66" value="1"/>
  <variable name="x112" index="112" value="1"/>
  <variable name="x149" index="149" value="1"/>
  <variable name="x172" index="172" value="1"/>
  <variable name="x203" index="203" value="1"/>
  <variable name="x213" index="213" value="1"/>
  <variable name="x215" index="215" value="1"/>
  <variable name="x219" index="219" value="1"/>
  <variable name="x221" index="221" value="1"/>
  <variable name="x222" index="222" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-917609.18870756542"/>
 </objectiveValues>
</CPLEXSolution>
