<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1213164.3975291552"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="32"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x5" index="5" value="1"/>
  <variable name="x39" index="39" value="1"/>
  <variable name="x76" index="76" value="1"/>
  <variable name="x101" index="101" value="1"/>
  <variable name="x164" index="164" value="1"/>
  <variable name="x191" index="191" value="1"/>
  <variable name="x203" index="203" value="1"/>
  <variable name="x242" index="242" value="1"/>
  <variable name="x257" index="257" value="1"/>
  <variable name="x261" index="261" value="1"/>
  <variable name="x262" index="262" value="1"/>
  <variable name="x269" index="269" value="1"/>
  <variable name="x273" index="273" value="1"/>
  <variable name="x275" index="275" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1213164.3975291552"/>
 </objectiveValues>
</CPLEXSolution>
