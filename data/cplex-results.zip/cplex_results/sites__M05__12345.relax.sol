<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__12345.mps"
   objectiveValue="-1363480.2166945967"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1261"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.3655745685100555e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="149512.25508534309"
   maxSlack="1"
   maxRedCost="150183.17037464757"
   kappa="15233.266666666666"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1363480.2166945965"/>
 </objectiveValues>
</CPLEXSolution>
