<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__45678.mps"
   objectiveValue="-191013.54267931037"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="120"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95517.427796899399"
   maxSlack="1"
   maxRedCost="50324.750051861949"
   kappa="8639.3999999999996"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-191013.54267931037"/>
 </objectiveValues>
</CPLEXSolution>
