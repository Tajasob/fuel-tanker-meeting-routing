<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__90123.mps"
   objectiveValue="-777591.77149719931"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2189"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.1827872842550278e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145561.52941898955"
   maxSlack="1"
   maxRedCost="150088.49456394033"
   kappa="172901"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-777591.77149719931"/>
 </objectiveValues>
</CPLEXSolution>
