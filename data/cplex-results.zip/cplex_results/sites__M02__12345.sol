<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-927005.32908287772"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="396"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x138" index="138" value="1"/>
  <variable name="x469" index="469" value="1"/>
  <variable name="x726" index="726" value="1"/>
  <variable name="x914" index="914" value="1"/>
  <variable name="x1295" index="1295" value="1"/>
  <variable name="x2039" index="2039" value="1"/>
  <variable name="x3545" index="3545" value="1"/>
  <variable name="x4123" index="4123" value="1"/>
  <variable name="x11428" index="11428" value="1"/>
  <variable name="x12120" index="12120" value="1"/>
  <variable name="x21144" index="21144" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-927005.32908287772"/>
 </objectiveValues>
</CPLEXSolution>
