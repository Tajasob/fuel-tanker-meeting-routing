<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__23456.mps"
   objectiveValue="-2825.794716508859"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2394"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.2737367544323206e-13"
   maxPrimalResidual="0"
   maxDualResidual="2.2737367544323206e-13"
   maxX="1"
   maxPi="4824.5003237293613"
   maxSlack="1"
   maxRedCost="5332.3639146880832"
   kappa="180747"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-2825.794716508859"/>
 </objectiveValues>
</CPLEXSolution>
