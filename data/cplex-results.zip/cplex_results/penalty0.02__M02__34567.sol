<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-2461.772849238027"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2301"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3885" index="3885" value="1"/>
  <variable name="x8311" index="8311" value="1"/>
  <variable name="x89136" index="89136" value="1"/>
  <variable name="x234100" index="234100" value="1"/>
  <variable name="x258627" index="258627" value="1"/>
  <variable name="x732979" index="732979" value="1"/>
  <variable name="x788640" index="788640" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-2461.772849238027"/>
 </objectiveValues>
</CPLEXSolution>
