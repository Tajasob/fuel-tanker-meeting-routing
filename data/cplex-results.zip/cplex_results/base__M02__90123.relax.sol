<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__90123.mps"
   objectiveValue="-927367.26688717748"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1606"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.3655745685100555e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.1827872842550278e-11"
   maxX="1"
   maxPi="195525.36238256161"
   maxSlack="1"
   maxRedCost="200207.96095638568"
   kappa="119649.77777777778"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-927367.2668871776"/>
 </objectiveValues>
</CPLEXSolution>
