<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__78901.mps"
   objectiveValue="-801769.90407586761"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7777"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.8207660913467407e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195302.0060707228"
   maxSlack="1"
   maxRedCost="175306.11281772016"
   kappa="262350.55555555556"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-801769.90407586761"/>
 </objectiveValues>
</CPLEXSolution>
