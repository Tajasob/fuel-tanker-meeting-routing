<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__11223.mps"
   objectiveValue="-27434.232420713884"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7825"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.7284841053187847e-12"
   maxPrimalResidual="0"
   maxDualResidual="9.0949470177292824e-13"
   maxX="1"
   maxPi="7145.5913502434551"
   maxSlack="1"
   maxRedCost="7499.1323748164768"
   kappa="514554.8571428571"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-27434.232420713881"/>
 </objectiveValues>
</CPLEXSolution>
