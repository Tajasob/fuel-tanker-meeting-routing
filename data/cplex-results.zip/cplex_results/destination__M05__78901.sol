<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1212141.8423489858"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="63"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x4" index="4" value="1"/>
  <variable name="x44" index="44" value="1"/>
  <variable name="x69" index="69" value="1"/>
  <variable name="x101" index="101" value="1"/>
  <variable name="x144" index="144" value="1"/>
  <variable name="x169" index="169" value="1"/>
  <variable name="x194" index="194" value="1"/>
  <variable name="x221" index="221" value="1"/>
  <variable name="x244" index="244" value="1"/>
  <variable name="x246" index="246" value="1"/>
  <variable name="x248" index="248" value="1"/>
  <variable name="x258" index="258" value="1"/>
  <variable name="x262" index="262" value="1"/>
  <variable name="x263" index="263" value="1"/>
  <variable name="x273" index="273" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1212141.8423489858"/>
 </objectiveValues>
</CPLEXSolution>
