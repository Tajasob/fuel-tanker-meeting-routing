<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__78901.mps"
   objectiveValue="-876767.32419440686"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="555"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="219966.73884124064"
   maxSlack="1"
   maxRedCost="199528.46899492631"
   kappa="4143.2222222222226"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-876767.32419440686"/>
 </objectiveValues>
</CPLEXSolution>
