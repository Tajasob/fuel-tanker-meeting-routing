<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__56789.mps"
   objectiveValue="-977275.10603009979"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="4438"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.0931703299283981e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195472.77256651831"
   maxSlack="1"
   maxRedCost="150480.19468294003"
   kappa="476200.42105263157"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-977275.10603009979"/>
 </objectiveValues>
</CPLEXSolution>
