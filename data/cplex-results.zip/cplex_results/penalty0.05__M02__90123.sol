<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-24867.266887177389"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1958"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x748" index="748" value="1"/>
  <variable name="x3769" index="3769" value="1"/>
  <variable name="x5712" index="5712" value="1"/>
  <variable name="x8230" index="8230" value="1"/>
  <variable name="x10048" index="10048" value="1"/>
  <variable name="x36684" index="36684" value="1"/>
  <variable name="x210797" index="210797" value="1"/>
  <variable name="x325972" index="325972" value="1"/>
  <variable name="x339976" index="339976" value="1"/>
  <variable name="x356163" index="356163" value="1"/>
  <variable name="x393046" index="393046" value="1"/>
  <variable name="x473451" index="473451" value="1"/>
  <variable name="x506131" index="506131" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-24867.266887177389"/>
 </objectiveValues>
</CPLEXSolution>
