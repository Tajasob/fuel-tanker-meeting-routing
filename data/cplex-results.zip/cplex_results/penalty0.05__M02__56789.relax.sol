<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__56789.mps"
   objectiveValue="-27275.106030099832"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="5072"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="9.0949470177292824e-13"
   maxPrimalResidual="0"
   maxDualResidual="9.0949470177292824e-13"
   maxX="1"
   maxPi="9682.9730701316075"
   maxSlack="1"
   maxRedCost="10040.353126633059"
   kappa="307503.81818181818"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-27275.106030099836"/>
 </objectiveValues>
</CPLEXSolution>
