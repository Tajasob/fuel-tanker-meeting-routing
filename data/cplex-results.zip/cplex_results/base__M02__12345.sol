<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-977212.73608665145"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="50"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1792" index="1792" value="1"/>
  <variable name="x3009" index="3009" value="1"/>
  <variable name="x4820" index="4820" value="1"/>
  <variable name="x6883" index="6883" value="1"/>
  <variable name="x9719" index="9719" value="1"/>
  <variable name="x60976" index="60976" value="1"/>
  <variable name="x469340" index="469340" value="1"/>
  <variable name="x582974" index="582974" value="1"/>
  <variable name="x674179" index="674179" value="1"/>
  <variable name="x821749" index="821749" value="1"/>
  <variable name="x822442" index="822442" value="1"/>
  <variable name="x877365" index="877365" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-977212.73608665145"/>
 </objectiveValues>
</CPLEXSolution>
