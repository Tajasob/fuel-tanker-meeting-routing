<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__90123.mps"
   objectiveValue="-676758.48202765209"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="20"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145233.52112430072"
   maxSlack="1"
   maxRedCost="100121.014618602"
   kappa="24.444444444444443"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-676758.48202765221"/>
 </objectiveValues>
</CPLEXSolution>
