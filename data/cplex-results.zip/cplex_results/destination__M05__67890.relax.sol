<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__67890.mps"
   objectiveValue="-1167183.3562986131"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="78"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="195334.12109825588"
   maxSlack="1"
   maxRedCost="150315.57251024459"
   kappa="48.181818181818187"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1167183.3562986131"/>
 </objectiveValues>
</CPLEXSolution>
