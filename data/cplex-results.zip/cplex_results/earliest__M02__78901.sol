<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-332966.1647416398"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x16" index="16" value="1"/>
  <variable name="x21" index="21" value="1"/>
  <variable name="x29" index="29" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-332966.1647416398"/>
 </objectiveValues>
</CPLEXSolution>
