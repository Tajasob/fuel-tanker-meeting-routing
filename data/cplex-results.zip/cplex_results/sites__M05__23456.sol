<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1262952.1869480996"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="495"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x117" index="117" value="1"/>
  <variable name="x287" index="287" value="1"/>
  <variable name="x736" index="736" value="1"/>
  <variable name="x1052" index="1052" value="1"/>
  <variable name="x1767" index="1767" value="1"/>
  <variable name="x2039" index="2039" value="1"/>
  <variable name="x2562" index="2562" value="1"/>
  <variable name="x2862" index="2862" value="1"/>
  <variable name="x3121" index="3121" value="1"/>
  <variable name="x3419" index="3419" value="1"/>
  <variable name="x4973" index="4973" value="1"/>
  <variable name="x9554" index="9554" value="1"/>
  <variable name="x13349" index="13349" value="1"/>
  <variable name="x18804" index="18804" value="1"/>
  <variable name="x23470" index="23470" value="1"/>
  <variable name="x23527" index="23527" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1262952.1869480996"/>
 </objectiveValues>
</CPLEXSolution>
