<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__34567.mps"
   objectiveValue="-191107.48690506004"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="160"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99689.924285522604"
   maxSlack="1"
   maxRedCost="50436.321934162435"
   kappa="24806"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-191107.48690506004"/>
 </objectiveValues>
</CPLEXSolution>
