<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1637.2863163339791"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2702"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1200" index="1200" value="1"/>
  <variable name="x12218" index="12218" value="1"/>
  <variable name="x17837" index="17837" value="1"/>
  <variable name="x122890" index="122890" value="1"/>
  <variable name="x294584" index="294584" value="1"/>
  <variable name="x529613" index="529613" value="1"/>
  <variable name="x841273" index="841273" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1637.2863163339791"/>
 </objectiveValues>
</CPLEXSolution>
