<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__67890.mps"
   objectiveValue="-145336.15672073301"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="3"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99538.877384734602"
   maxSlack="1"
   maxRedCost="50097.708006461704"
   kappa="17.333333333333332"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-145336.15672073301"/>
 </objectiveValues>
</CPLEXSolution>
