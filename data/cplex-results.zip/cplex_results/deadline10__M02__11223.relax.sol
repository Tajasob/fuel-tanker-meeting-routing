<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__11223.mps"
   objectiveValue="-876858.73147660447"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7101"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="95941.416234851757"
   maxSlack="1"
   maxRedCost="100695.44247189072"
   kappa="1014415.2631578947"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-876858.73147660436"/>
 </objectiveValues>
</CPLEXSolution>
