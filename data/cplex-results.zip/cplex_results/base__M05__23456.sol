<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1813194.3878146624"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="6518"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x995" index="995" value="1"/>
  <variable name="x2392" index="2392" value="1"/>
  <variable name="x5161" index="5161" value="1"/>
  <variable name="x7624" index="7624" value="1"/>
  <variable name="x12873" index="12873" value="1"/>
  <variable name="x15142" index="15142" value="1"/>
  <variable name="x18526" index="18526" value="1"/>
  <variable name="x20712" index="20712" value="1"/>
  <variable name="x22666" index="22666" value="1"/>
  <variable name="x96073" index="96073" value="1"/>
  <variable name="x168337" index="168337" value="1"/>
  <variable name="x329449" index="329449" value="1"/>
  <variable name="x991749" index="991749" value="1"/>
  <variable name="x1061632" index="1061632" value="1"/>
  <variable name="x1077634" index="1077634" value="1"/>
  <variable name="x1145399" index="1145399" value="1"/>
  <variable name="x1162013" index="1162013" value="1"/>
  <variable name="x1175268" index="1175268" value="1"/>
  <variable name="x1307626" index="1307626" value="1"/>
  <variable name="x1477860" index="1477860" value="1"/>
  <variable name="x1571726" index="1571726" value="1"/>
  <variable name="x1622022" index="1622022" value="1"/>
  <variable name="x1663530" index="1663530" value="1"/>
  <variable name="x1815540" index="1815540" value="1"/>
  <variable name="x1855161" index="1855161" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1813194.3878146624"/>
 </objectiveValues>
</CPLEXSolution>
