<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__23456.mps"
   objectiveValue="-241062.39371876753"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="7"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95673.827532010997"
   maxSlack="1"
   maxRedCost="100374.8190577106"
   kappa="30"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-241062.39371876753"/>
 </objectiveValues>
</CPLEXSolution>
