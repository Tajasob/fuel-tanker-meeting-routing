<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-429060.52843418613"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x18" index="18" value="1"/>
  <variable name="x33" index="33" value="1"/>
  <variable name="x48" index="48" value="1"/>
  <variable name="x52" index="52" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-429060.52843418613"/>
 </objectiveValues>
</CPLEXSolution>
