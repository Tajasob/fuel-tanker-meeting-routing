<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__78901.mps"
   objectiveValue="-976875.61116573622"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="11077"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.1641532182693481e-10"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="245140.78081521767"
   maxSlack="1"
   maxRedCost="200237.08624588689"
   kappa="180637.36842105264"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-976875.6111657361"/>
 </objectiveValues>
</CPLEXSolution>
