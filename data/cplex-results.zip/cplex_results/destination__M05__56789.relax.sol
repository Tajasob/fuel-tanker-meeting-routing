<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__56789.mps"
   objectiveValue="-1213164.3975291552"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="32"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="95647.243181277867"
   maxSlack="1"
   maxRedCost="100142.51122304055"
   kappa="25.714285714285715"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1213164.3975291552"/>
 </objectiveValues>
</CPLEXSolution>
