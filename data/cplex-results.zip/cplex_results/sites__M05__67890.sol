<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1467436.4485039469"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1349"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x455" index="455" value="1"/>
  <variable name="x675" index="675" value="1"/>
  <variable name="x692" index="692" value="1"/>
  <variable name="x1430" index="1430" value="1"/>
  <variable name="x2272" index="2272" value="1"/>
  <variable name="x2369" index="2369" value="1"/>
  <variable name="x2786" index="2786" value="1"/>
  <variable name="x3869" index="3869" value="1"/>
  <variable name="x6643" index="6643" value="1"/>
  <variable name="x17074" index="17074" value="1"/>
  <variable name="x18051" index="18051" value="1"/>
  <variable name="x18069" index="18069" value="1"/>
  <variable name="x19477" index="19477" value="1"/>
  <variable name="x25892" index="25892" value="1"/>
  <variable name="x27210" index="27210" value="1"/>
  <variable name="x28910" index="28910" value="1"/>
  <variable name="x36125" index="36125" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1467436.4485039469"/>
 </objectiveValues>
</CPLEXSolution>
