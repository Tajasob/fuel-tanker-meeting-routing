<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__56789.mps"
   objectiveValue="-677439.99624766759"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="223"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145229.47058027709"
   maxSlack="1"
   maxRedCost="149839.90164633276"
   kappa="693"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-677439.9962476677"/>
 </objectiveValues>
</CPLEXSolution>
