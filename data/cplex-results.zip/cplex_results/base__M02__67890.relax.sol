<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__67890.mps"
   objectiveValue="-977052.63534756913"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="8113"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.3655745685100555e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.1827872842550278e-11"
   maxX="1"
   maxPi="195502.33114905399"
   maxSlack="1"
   maxRedCost="200449.82102974749"
   kappa="120013.5238095238"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-977052.63534756913"/>
 </objectiveValues>
</CPLEXSolution>
