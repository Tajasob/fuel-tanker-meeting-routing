<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__45678.mps"
   objectiveValue="-727111.85220666684"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="545"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95709.938976901292"
   maxSlack="1"
   maxRedCost="100142.52872213964"
   kappa="12856.23076923077"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-727111.85220666684"/>
 </objectiveValues>
</CPLEXSolution>
