<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-527048.02908083191"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="5"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x4" index="4" value="1"/>
  <variable name="x29" index="29" value="1"/>
  <variable name="x45" index="45" value="1"/>
  <variable name="x67" index="67" value="1"/>
  <variable name="x82" index="82" value="1"/>
  <variable name="x90" index="90" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-527048.02908083179"/>
 </objectiveValues>
</CPLEXSolution>
