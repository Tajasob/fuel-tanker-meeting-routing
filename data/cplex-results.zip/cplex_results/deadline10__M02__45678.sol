<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-777491.9859550657"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1770"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x873" index="873" value="1"/>
  <variable name="x2937" index="2937" value="1"/>
  <variable name="x2993" index="2993" value="1"/>
  <variable name="x5648" index="5648" value="1"/>
  <variable name="x7087" index="7087" value="1"/>
  <variable name="x77728" index="77728" value="1"/>
  <variable name="x270735" index="270735" value="1"/>
  <variable name="x348285" index="348285" value="1"/>
  <variable name="x374239" index="374239" value="1"/>
  <variable name="x376556" index="376556" value="1"/>
  <variable name="x466363" index="466363" value="1"/>
  <variable name="x514855" index="514855" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-777491.9859550657"/>
 </objectiveValues>
</CPLEXSolution>
