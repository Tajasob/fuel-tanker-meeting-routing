<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__34567.mps"
   objectiveValue="-1888121.1418540759"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="62190"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="8.7311491370201111e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="244902.29333977963"
   maxSlack="1"
   maxRedCost="249425.6323986754"
   kappa="108406.67441860464"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1888121.1418540759"/>
 </objectiveValues>
</CPLEXSolution>
