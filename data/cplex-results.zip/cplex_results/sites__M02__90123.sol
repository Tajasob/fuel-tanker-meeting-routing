<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-826708.27146151394"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="257"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x40" index="40" value="1"/>
  <variable name="x662" index="662" value="1"/>
  <variable name="x1008" index="1008" value="1"/>
  <variable name="x1462" index="1462" value="1"/>
  <variable name="x1768" index="1768" value="1"/>
  <variable name="x2722" index="2722" value="1"/>
  <variable name="x4893" index="4893" value="1"/>
  <variable name="x6524" index="6524" value="1"/>
  <variable name="x6580" index="6580" value="1"/>
  <variable name="x6703" index="6703" value="1"/>
  <variable name="x7777" index="7777" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-826708.27146151394"/>
 </objectiveValues>
</CPLEXSolution>
