<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__23456.mps"
   objectiveValue="-877252.89678800153"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1640"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="7.2759576141834259e-12"
   maxX="1"
   maxPi="145516.15253071982"
   maxSlack="1"
   maxRedCost="150033.59109311667"
   kappa="97433.636363636368"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-877252.89678800153"/>
 </objectiveValues>
</CPLEXSolution>
