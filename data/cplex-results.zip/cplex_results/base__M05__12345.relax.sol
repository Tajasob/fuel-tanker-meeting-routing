<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__12345.mps"
   objectiveValue="-1888307.3342737125"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="24372"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.1641532182693481e-10"
   maxPrimalResidual="0"
   maxDualResidual="5.8207660913467407e-11"
   maxX="1"
   maxPi="207983.49286241349"
   maxSlack="1"
   maxRedCost="187602.33131506576"
   kappa="516449.73076923075"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1888307.334273712"/>
 </objectiveValues>
</CPLEXSolution>
