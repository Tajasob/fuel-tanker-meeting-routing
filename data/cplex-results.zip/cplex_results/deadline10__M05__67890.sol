<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1368323.6758438931"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="4210"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2488" index="2488" value="1"/>
  <variable name="x3294" index="3294" value="1"/>
  <variable name="x5776" index="5776" value="1"/>
  <variable name="x7961" index="7961" value="1"/>
  <variable name="x13557" index="13557" value="1"/>
  <variable name="x14947" index="14947" value="1"/>
  <variable name="x16127" index="16127" value="1"/>
  <variable name="x19242" index="19242" value="1"/>
  <variable name="x464217" index="464217" value="1"/>
  <variable name="x494079" index="494079" value="1"/>
  <variable name="x651805" index="651805" value="1"/>
  <variable name="x717701" index="717701" value="1"/>
  <variable name="x726444" index="726444" value="1"/>
  <variable name="x795523" index="795523" value="1"/>
  <variable name="x812819" index="812819" value="1"/>
  <variable name="x917604" index="917604" value="1"/>
  <variable name="x1027759" index="1027759" value="1"/>
  <variable name="x1086520" index="1086520" value="1"/>
  <variable name="x1285147" index="1285147" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1368323.6758438931"/>
 </objectiveValues>
</CPLEXSolution>
