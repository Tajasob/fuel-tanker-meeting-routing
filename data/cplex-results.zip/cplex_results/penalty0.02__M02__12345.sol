<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1932.5671012839964"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1382"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x908" index="908" value="1"/>
  <variable name="x8488" index="8488" value="1"/>
  <variable name="x60847" index="60847" value="1"/>
  <variable name="x287903" index="287903" value="1"/>
  <variable name="x456007" index="456007" value="1"/>
  <variable name="x837970" index="837970" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1932.5671012839964"/>
 </objectiveValues>
</CPLEXSolution>
