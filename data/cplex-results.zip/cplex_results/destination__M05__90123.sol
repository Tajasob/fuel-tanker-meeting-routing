<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-913177.48804067285"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="20"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x21" index="21" value="1"/>
  <variable name="x44" index="44" value="1"/>
  <variable name="x70" index="70" value="1"/>
  <variable name="x115" index="115" value="1"/>
  <variable name="x152" index="152" value="1"/>
  <variable name="x173" index="173" value="1"/>
  <variable name="x182" index="182" value="1"/>
  <variable name="x207" index="207" value="1"/>
  <variable name="x232" index="232" value="1"/>
  <variable name="x235" index="235" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-913177.48804067285"/>
 </objectiveValues>
</CPLEXSolution>
