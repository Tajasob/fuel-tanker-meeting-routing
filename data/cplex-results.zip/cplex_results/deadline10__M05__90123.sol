<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1414053.4739011081"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2365"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2155" index="2155" value="1"/>
  <variable name="x4850" index="4850" value="1"/>
  <variable name="x5917" index="5917" value="1"/>
  <variable name="x9442" index="9442" value="1"/>
  <variable name="x13409" index="13409" value="1"/>
  <variable name="x13990" index="13990" value="1"/>
  <variable name="x14475" index="14475" value="1"/>
  <variable name="x17173" index="17173" value="1"/>
  <variable name="x65632" index="65632" value="1"/>
  <variable name="x276751" index="276751" value="1"/>
  <variable name="x313612" index="313612" value="1"/>
  <variable name="x352193" index="352193" value="1"/>
  <variable name="x393707" index="393707" value="1"/>
  <variable name="x410115" index="410115" value="1"/>
  <variable name="x505724" index="505724" value="1"/>
  <variable name="x525781" index="525781" value="1"/>
  <variable name="x606819" index="606819" value="1"/>
  <variable name="x637538" index="637538" value="1"/>
  <variable name="x652678" index="652678" value="1"/>
  <variable name="x678891" index="678891" value="1"/>
  <variable name="x697634" index="697634" value="1"/>
  <variable name="x740506" index="740506" value="1"/>
  <variable name="x813882" index="813882" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1414053.4739011081"/>
 </objectiveValues>
</CPLEXSolution>
