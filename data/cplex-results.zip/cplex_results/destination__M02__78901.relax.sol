<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__78901.mps"
   objectiveValue="-626532.57169620402"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="21"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145184.82931003327"
   maxSlack="1"
   maxRedCost="100235.27129351062"
   kappa="32"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-626532.57169620402"/>
 </objectiveValues>
</CPLEXSolution>
