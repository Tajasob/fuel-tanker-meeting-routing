<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__45678.mps"
   objectiveValue="-1112269.6580554764"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="58"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="95539.522682940646"
   maxSlack="1"
   maxRedCost="50686.398715774529"
   kappa="58"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1112269.6580554768"/>
 </objectiveValues>
</CPLEXSolution>
