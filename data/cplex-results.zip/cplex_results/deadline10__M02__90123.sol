<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-777591.7714971992"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1229"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x259" index="259" value="1"/>
  <variable name="x2181" index="2181" value="1"/>
  <variable name="x4372" index="4372" value="1"/>
  <variable name="x6352" index="6352" value="1"/>
  <variable name="x7873" index="7873" value="1"/>
  <variable name="x45119" index="45119" value="1"/>
  <variable name="x118952" index="118952" value="1"/>
  <variable name="x162370" index="162370" value="1"/>
  <variable name="x265163" index="265163" value="1"/>
  <variable name="x278116" index="278116" value="1"/>
  <variable name="x290878" index="290878" value="1"/>
  <variable name="x361176" index="361176" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-777591.7714971992"/>
 </objectiveValues>
</CPLEXSolution>
