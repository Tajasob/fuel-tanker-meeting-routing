<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-428463.33761055558"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x4" index="4" value="1"/>
  <variable name="x8" index="8" value="1"/>
  <variable name="x9" index="9" value="1"/>
  <variable name="x17" index="17" value="1"/>
  <variable name="x33" index="33" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-428463.33761055558"/>
 </objectiveValues>
</CPLEXSolution>
