<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-627272.70351209491"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1340"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x231" index="231" value="1"/>
  <variable name="x1172" index="1172" value="1"/>
  <variable name="x1729" index="1729" value="1"/>
  <variable name="x2912" index="2912" value="1"/>
  <variable name="x4278" index="4278" value="1"/>
  <variable name="x132309" index="132309" value="1"/>
  <variable name="x143536" index="143536" value="1"/>
  <variable name="x267735" index="267735" value="1"/>
  <variable name="x333817" index="333817" value="1"/>
  <variable name="x412162" index="412162" value="1"/>
  <variable name="x426015" index="426015" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-627272.70351209491"/>
 </objectiveValues>
</CPLEXSolution>
