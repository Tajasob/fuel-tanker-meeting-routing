<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1617538.0675399017"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="41"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x849" index="849" value="1"/>
  <variable name="x1091" index="1091" value="1"/>
  <variable name="x8017" index="8017" value="1"/>
  <variable name="x14346" index="14346" value="1"/>
  <variable name="x17570" index="17570" value="1"/>
  <variable name="x21445" index="21445" value="1"/>
  <variable name="x26885" index="26885" value="1"/>
  <variable name="x225411" index="225411" value="1"/>
  <variable name="x499849" index="499849" value="1"/>
  <variable name="x565769" index="565769" value="1"/>
  <variable name="x602064" index="602064" value="1"/>
  <variable name="x760013" index="760013" value="1"/>
  <variable name="x784632" index="784632" value="1"/>
  <variable name="x832492" index="832492" value="1"/>
  <variable name="x1050456" index="1050456" value="1"/>
  <variable name="x1136485" index="1136485" value="1"/>
  <variable name="x1448423" index="1448423" value="1"/>
  <variable name="x1896311" index="1896311" value="1"/>
  <variable name="x1985202" index="1985202" value="1"/>
  <variable name="x1992939" index="1992939" value="1"/>
  <variable name="x2000771" index="2000771" value="1"/>
  <variable name="x2251229" index="2251229" value="1"/>
  <variable name="x2382078" index="2382078" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1617538.0675399017"/>
 </objectiveValues>
</CPLEXSolution>
