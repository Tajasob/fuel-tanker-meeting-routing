<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-670662.05527196079"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x8" index="8" value="1"/>
  <variable name="x10" index="10" value="1"/>
  <variable name="x16" index="16" value="1"/>
  <variable name="x20" index="20" value="1"/>
  <variable name="x43" index="43" value="1"/>
  <variable name="x45" index="45" value="1"/>
  <variable name="x46" index="46" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-670662.05527196079"/>
 </objectiveValues>
</CPLEXSolution>
