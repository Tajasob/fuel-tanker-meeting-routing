<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-977275.10603009991"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="36"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1178" index="1178" value="1"/>
  <variable name="x3450" index="3450" value="1"/>
  <variable name="x4944" index="4944" value="1"/>
  <variable name="x7553" index="7553" value="1"/>
  <variable name="x9383" index="9383" value="1"/>
  <variable name="x153776" index="153776" value="1"/>
  <variable name="x411216" index="411216" value="1"/>
  <variable name="x416163" index="416163" value="1"/>
  <variable name="x451107" index="451107" value="1"/>
  <variable name="x464492" index="464492" value="1"/>
  <variable name="x489202" index="489202" value="1"/>
  <variable name="x966502" index="966502" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-977275.10603009979"/>
 </objectiveValues>
</CPLEXSolution>
