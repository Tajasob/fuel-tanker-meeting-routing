<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1126748.3301527286"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3826"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x255" index="255" value="1"/>
  <variable name="x2353" index="2353" value="1"/>
  <variable name="x3311" index="3311" value="1"/>
  <variable name="x8310" index="8310" value="1"/>
  <variable name="x10678" index="10678" value="1"/>
  <variable name="x89137" index="89137" value="1"/>
  <variable name="x113942" index="113942" value="1"/>
  <variable name="x131197" index="131197" value="1"/>
  <variable name="x395199" index="395199" value="1"/>
  <variable name="x546234" index="546234" value="1"/>
  <variable name="x561809" index="561809" value="1"/>
  <variable name="x585374" index="585374" value="1"/>
  <variable name="x733126" index="733126" value="1"/>
  <variable name="x788563" index="788563" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1126748.3301527286"/>
 </objectiveValues>
</CPLEXSolution>
