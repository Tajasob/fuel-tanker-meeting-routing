<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__11223.mps"
   objectiveValue="-1912853.1297990545"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="80784"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.0186340659856796e-10"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="199342.14156300164"
   maxSlack="1"
   maxRedCost="200480.56169764569"
   kappa="2107790.7692307695"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1912853.1297990545"/>
 </objectiveValues>
</CPLEXSolution>
