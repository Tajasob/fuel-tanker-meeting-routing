<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M02__23456.mps"
   objectiveValue="-478738.97823160933"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95811.010067567579"
   maxSlack="1"
   maxRedCost="50279.633154454204"
   kappa="5.5999999999999996"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-478738.97823160928"/>
 </objectiveValues>
</CPLEXSolution>
