<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-676758.48202765221"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="12"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x32" index="32" value="1"/>
  <variable name="x46" index="46" value="1"/>
  <variable name="x57" index="57" value="1"/>
  <variable name="x94" index="94" value="1"/>
  <variable name="x96" index="96" value="1"/>
  <variable name="x100" index="100" value="1"/>
  <variable name="x103" index="103" value="1"/>
  <variable name="x106" index="106" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-676758.48202765221"/>
 </objectiveValues>
</CPLEXSolution>
