<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1212653.4990883968"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="30"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x9" index="9" value="1"/>
  <variable name="x42" index="42" value="1"/>
  <variable name="x72" index="72" value="1"/>
  <variable name="x108" index="108" value="1"/>
  <variable name="x166" index="166" value="1"/>
  <variable name="x169" index="169" value="1"/>
  <variable name="x214" index="214" value="1"/>
  <variable name="x258" index="258" value="1"/>
  <variable name="x261" index="261" value="1"/>
  <variable name="x268" index="268" value="1"/>
  <variable name="x271" index="271" value="1"/>
  <variable name="x274" index="274" value="1"/>
  <variable name="x278" index="278" value="1"/>
  <variable name="x279" index="279" value="1"/>
  <variable name="x283" index="283" value="1"/>
  <variable name="x287" index="287" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1212653.4990883968"/>
 </objectiveValues>
</CPLEXSolution>
