<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__12345.mps"
   objectiveValue="-1212653.4990883963"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="32"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145270.46210579766"
   maxSlack="1"
   maxRedCost="149686.75722264277"
   kappa="25.454545454545453"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1212653.4990883968"/>
 </objectiveValues>
</CPLEXSolution>
