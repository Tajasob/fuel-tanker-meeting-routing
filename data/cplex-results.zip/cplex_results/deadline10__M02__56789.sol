<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-827599.02406333736"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1104"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x357" index="357" value="1"/>
  <variable name="x2478" index="2478" value="1"/>
  <variable name="x3826" index="3826" value="1"/>
  <variable name="x5895" index="5895" value="1"/>
  <variable name="x7300" index="7300" value="1"/>
  <variable name="x17150" index="17150" value="1"/>
  <variable name="x23507" index="23507" value="1"/>
  <variable name="x121712" index="121712" value="1"/>
  <variable name="x335298" index="335298" value="1"/>
  <variable name="x625771" index="625771" value="1"/>
  <variable name="x772771" index="772771" value="1"/>
  <variable name="x841510" index="841510" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-827599.02406333736"/>
 </objectiveValues>
</CPLEXSolution>
