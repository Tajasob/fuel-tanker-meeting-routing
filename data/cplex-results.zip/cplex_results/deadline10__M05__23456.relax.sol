<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__23456.mps"
   objectiveValue="-1238863.8378441199"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="9110"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="3.637978807091713e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195390.77373656159"
   maxSlack="1"
   maxRedCost="200013.86933430631"
   kappa="230813.17647058822"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1238863.8378441201"/>
 </objectiveValues>
</CPLEXSolution>
