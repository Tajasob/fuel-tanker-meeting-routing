<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__45678.mps"
   objectiveValue="-191157.90591764089"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="22"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99758.389307332662"
   maxSlack="1"
   maxRedCost="50167.191391007691"
   kappa="380"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-191157.90591764089"/>
 </objectiveValues>
</CPLEXSolution>
