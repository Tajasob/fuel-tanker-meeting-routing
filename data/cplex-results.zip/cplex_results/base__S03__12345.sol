<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-191139.33975640993"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x77" index="77" value="1"/>
  <variable name="x292" index="292" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-191139.33975640993"/>
 </objectiveValues>
</CPLEXSolution>
