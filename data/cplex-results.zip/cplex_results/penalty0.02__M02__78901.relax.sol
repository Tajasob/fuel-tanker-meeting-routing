<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__78901.mps"
   objectiveValue="-1637.2863163339794"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2280"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="9.0949470177292824e-13"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="3650.0435481381378"
   maxSlack="1"
   maxRedCost="4355.9948912571745"
   kappa="310708.20000000001"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1637.2863163339794"/>
 </objectiveValues>
</CPLEXSolution>
