<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-727364.57926163671"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="579"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x499" index="499" value="1"/>
  <variable name="x1938" index="1938" value="1"/>
  <variable name="x2962" index="2962" value="1"/>
  <variable name="x3922" index="3922" value="1"/>
  <variable name="x5700" index="5700" value="1"/>
  <variable name="x60029" index="60029" value="1"/>
  <variable name="x76305" index="76305" value="1"/>
  <variable name="x158867" index="158867" value="1"/>
  <variable name="x161468" index="161468" value="1"/>
  <variable name="x168516" index="168516" value="1"/>
  <variable name="x216320" index="216320" value="1"/>
  <variable name="x332068" index="332068" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-727364.57926163671"/>
 </objectiveValues>
</CPLEXSolution>
