<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__34567.mps"
   objectiveValue="-727455.69023467915"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1815"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145538.75289103342"
   maxSlack="1"
   maxRedCost="150079.07060293469"
   kappa="76832"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-727455.69023467915"/>
 </objectiveValues>
</CPLEXSolution>
