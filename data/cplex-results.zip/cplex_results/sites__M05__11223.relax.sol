<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__11223.mps"
   objectiveValue="-1512520.6848793782"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="931"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="3.637978807091713e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145503.10638421401"
   maxSlack="1"
   maxRedCost="150298.59627011826"
   kappa="9158.7692307692305"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1512520.6848793782"/>
 </objectiveValues>
</CPLEXSolution>
