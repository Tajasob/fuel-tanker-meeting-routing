<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-927367.26688717748"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2283"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x747" index="747" value="1"/>
  <variable name="x3766" index="3766" value="1"/>
  <variable name="x5712" index="5712" value="1"/>
  <variable name="x8233" index="8233" value="1"/>
  <variable name="x10048" index="10048" value="1"/>
  <variable name="x36457" index="36457" value="1"/>
  <variable name="x210796" index="210796" value="1"/>
  <variable name="x325972" index="325972" value="1"/>
  <variable name="x339909" index="339909" value="1"/>
  <variable name="x356334" index="356334" value="1"/>
  <variable name="x393046" index="393046" value="1"/>
  <variable name="x473166" index="473166" value="1"/>
  <variable name="x506131" index="506131" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-927367.26688717748"/>
 </objectiveValues>
</CPLEXSolution>
