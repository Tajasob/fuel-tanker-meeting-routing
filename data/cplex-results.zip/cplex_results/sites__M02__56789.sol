<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-677439.9962476677"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="138"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x137" index="137" value="1"/>
  <variable name="x446" index="446" value="1"/>
  <variable name="x748" index="748" value="1"/>
  <variable name="x972" index="972" value="1"/>
  <variable name="x1234" index="1234" value="1"/>
  <variable name="x1846" index="1846" value="1"/>
  <variable name="x3440" index="3440" value="1"/>
  <variable name="x3664" index="3664" value="1"/>
  <variable name="x7851" index="7851" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-677439.9962476677"/>
 </objectiveValues>
</CPLEXSolution>
