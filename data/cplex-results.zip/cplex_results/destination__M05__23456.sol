<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1162669.9260500683"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="20"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x30" index="30" value="1"/>
  <variable name="x59" index="59" value="1"/>
  <variable name="x71" index="71" value="1"/>
  <variable name="x104" index="104" value="1"/>
  <variable name="x143" index="143" value="1"/>
  <variable name="x171" index="171" value="1"/>
  <variable name="x199" index="199" value="1"/>
  <variable name="x211" index="211" value="1"/>
  <variable name="x217" index="217" value="1"/>
  <variable name="x220" index="220" value="1"/>
  <variable name="x227" index="227" value="1"/>
  <variable name="x233" index="233" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1162669.9260500681"/>
 </objectiveValues>
</CPLEXSolution>
