<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__89012.mps"
   objectiveValue="-917609.18870756531"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="26"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95547.301260460546"
   maxSlack="1"
   maxRedCost="100150.1149301969"
   kappa="52.533333333333331"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-917609.18870756542"/>
 </objectiveValues>
</CPLEXSolution>
