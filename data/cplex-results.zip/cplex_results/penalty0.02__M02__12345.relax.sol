<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__12345.mps"
   objectiveValue="-1932.5671012839964"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1557"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.5474735088646412e-13"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="3481.032948319571"
   maxSlack="1"
   maxRedCost="3988.2568259968739"
   kappa="568217"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1932.5671012839964"/>
 </objectiveValues>
</CPLEXSolution>
