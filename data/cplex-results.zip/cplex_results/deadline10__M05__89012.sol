<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1268195.8323236255"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="49"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x755" index="755" value="1"/>
  <variable name="x959" index="959" value="1"/>
  <variable name="x6323" index="6323" value="1"/>
  <variable name="x11390" index="11390" value="1"/>
  <variable name="x15513" index="15513" value="1"/>
  <variable name="x19688" index="19688" value="1"/>
  <variable name="x21830" index="21830" value="1"/>
  <variable name="x184736" index="184736" value="1"/>
  <variable name="x188742" index="188742" value="1"/>
  <variable name="x469400" index="469400" value="1"/>
  <variable name="x631191" index="631191" value="1"/>
  <variable name="x638908" index="638908" value="1"/>
  <variable name="x1130311" index="1130311" value="1"/>
  <variable name="x1146436" index="1146436" value="1"/>
  <variable name="x1365945" index="1365945" value="1"/>
  <variable name="x1526265" index="1526265" value="1"/>
  <variable name="x1589474" index="1589474" value="1"/>
  <variable name="x1597644" index="1597644" value="1"/>
  <variable name="x1787313" index="1787313" value="1"/>
  <variable name="x1890742" index="1890742" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1268195.8323236255"/>
 </objectiveValues>
</CPLEXSolution>
