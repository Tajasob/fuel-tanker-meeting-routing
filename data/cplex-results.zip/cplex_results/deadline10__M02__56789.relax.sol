<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__56789.mps"
   objectiveValue="-827599.02406333736"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="388"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="7.2759576141834259e-12"
   maxX="1"
   maxPi="195478.06724087801"
   maxSlack="1"
   maxRedCost="200040.35312663304"
   kappa="217524.85714285716"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-827599.02406333736"/>
 </objectiveValues>
</CPLEXSolution>
