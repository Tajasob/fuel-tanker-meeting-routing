<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1712881.750745106"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="6883"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2319" index="2319" value="1"/>
  <variable name="x3860" index="3860" value="1"/>
  <variable name="x7363" index="7363" value="1"/>
  <variable name="x9122" index="9122" value="1"/>
  <variable name="x14606" index="14606" value="1"/>
  <variable name="x19374" index="19374" value="1"/>
  <variable name="x20530" index="20530" value="1"/>
  <variable name="x23050" index="23050" value="1"/>
  <variable name="x200415" index="200415" value="1"/>
  <variable name="x351015" index="351015" value="1"/>
  <variable name="x489604" index="489604" value="1"/>
  <variable name="x561632" index="561632" value="1"/>
  <variable name="x570460" index="570460" value="1"/>
  <variable name="x591497" index="591497" value="1"/>
  <variable name="x627765" index="627765" value="1"/>
  <variable name="x647116" index="647116" value="1"/>
  <variable name="x723090" index="723090" value="1"/>
  <variable name="x846528" index="846528" value="1"/>
  <variable name="x888150" index="888150" value="1"/>
  <variable name="x1104254" index="1104254" value="1"/>
  <variable name="x1274131" index="1274131" value="1"/>
  <variable name="x1649729" index="1649729" value="1"/>
  <variable name="x1760142" index="1760142" value="1"/>
  <variable name="x1946362" index="1946362" value="1"/>
  <variable name="x2024197" index="2024197" value="1"/>
  <variable name="x2211570" index="2211570" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1712881.750745106"/>
 </objectiveValues>
</CPLEXSolution>
