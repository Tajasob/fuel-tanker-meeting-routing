<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1663891.2133804602"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="7430"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x555" index="555" value="1"/>
  <variable name="x6935" index="6935" value="1"/>
  <variable name="x8219" index="8219" value="1"/>
  <variable name="x12789" index="12789" value="1"/>
  <variable name="x18166" index="18166" value="1"/>
  <variable name="x18988" index="18988" value="1"/>
  <variable name="x20068" index="20068" value="1"/>
  <variable name="x23842" index="23842" value="1"/>
  <variable name="x81252" index="81252" value="1"/>
  <variable name="x304530" index="304530" value="1"/>
  <variable name="x321703" index="321703" value="1"/>
  <variable name="x414308" index="414308" value="1"/>
  <variable name="x521386" index="521386" value="1"/>
  <variable name="x585320" index="585320" value="1"/>
  <variable name="x600540" index="600540" value="1"/>
  <variable name="x706949" index="706949" value="1"/>
  <variable name="x732765" index="732765" value="1"/>
  <variable name="x849504" index="849504" value="1"/>
  <variable name="x906861" index="906861" value="1"/>
  <variable name="x920260" index="920260" value="1"/>
  <variable name="x984273" index="984273" value="1"/>
  <variable name="x1036867" index="1036867" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1663891.2133804599"/>
 </objectiveValues>
</CPLEXSolution>
