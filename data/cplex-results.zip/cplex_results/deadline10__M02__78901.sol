<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-776944.34068500774"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2982"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x219" index="219" value="1"/>
  <variable name="x850" index="850" value="1"/>
  <variable name="x3882" index="3882" value="1"/>
  <variable name="x6595" index="6595" value="1"/>
  <variable name="x9220" index="9220" value="1"/>
  <variable name="x16271" index="16271" value="1"/>
  <variable name="x34573" index="34573" value="1"/>
  <variable name="x116410" index="116410" value="1"/>
  <variable name="x138827" index="138827" value="1"/>
  <variable name="x220002" index="220002" value="1"/>
  <variable name="x555607" index="555607" value="1"/>
  <variable name="x555655" index="555655" value="1"/>
  <variable name="x610305" index="610305" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-776944.34068500774"/>
 </objectiveValues>
</CPLEXSolution>
