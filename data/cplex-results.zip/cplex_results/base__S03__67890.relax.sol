<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__67890.mps"
   objectiveValue="-141411.09384012126"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95679.516343307419"
   maxSlack="1"
   maxRedCost="50493.749725831782"
   kappa="4.666666666666667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-141411.09384012126"/>
 </objectiveValues>
</CPLEXSolution>
