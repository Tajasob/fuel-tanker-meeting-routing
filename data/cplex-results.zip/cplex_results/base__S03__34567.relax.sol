<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__34567.mps"
   objectiveValue="-290672.26922601252"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="129"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="7.2759576141834259e-12"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99689.481160583673"
   maxSlack="1"
   maxRedCost="100113.52080211086"
   kappa="1494.6666666666667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-290672.26922601252"/>
 </objectiveValues>
</CPLEXSolution>
