<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-876858.73147660436"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2747"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x465" index="465" value="1"/>
  <variable name="x3763" index="3763" value="1"/>
  <variable name="x4724" index="4724" value="1"/>
  <variable name="x6784" index="6784" value="1"/>
  <variable name="x6979" index="6979" value="1"/>
  <variable name="x179260" index="179260" value="1"/>
  <variable name="x270371" index="270371" value="1"/>
  <variable name="x317826" index="317826" value="1"/>
  <variable name="x349377" index="349377" value="1"/>
  <variable name="x371773" index="371773" value="1"/>
  <variable name="x485684" index="485684" value="1"/>
  <variable name="x529906" index="529906" value="1"/>
  <variable name="x608998" index="608998" value="1"/>
  <variable name="x672507" index="672507" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-876858.73147660436"/>
 </objectiveValues>
</CPLEXSolution>
