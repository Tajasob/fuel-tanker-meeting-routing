<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__12345.mps"
   objectiveValue="-27231.295834469653"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="4038"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.0927261579781771e-12"
   maxPrimalResidual="0"
   maxDualResidual="9.0949470177292824e-13"
   maxX="1"
   maxPi="5137.4202644403749"
   maxSlack="1"
   maxRedCost="5680.7797305646991"
   kappa="554697.77777777787"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-27231.295834469653"/>
 </objectiveValues>
</CPLEXSolution>
