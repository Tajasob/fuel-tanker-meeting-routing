<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__23456.mps"
   objectiveValue="-1077152.7886136614"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="5613"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="5.8207660913467407e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145664.20679078845"
   maxSlack="1"
   maxRedCost="150311.15040759576"
   kappa="129326.46666666667"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1077152.7886136614"/>
 </objectiveValues>
</CPLEXSolution>
