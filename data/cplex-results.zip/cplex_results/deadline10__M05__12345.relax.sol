<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__12345.mps"
   objectiveValue="-1413452.6134064868"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="12226"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="7.2759576141834259e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195276.81097212358"
   maxSlack="1"
   maxRedCost="199828.82790516215"
   kappa="1135922.1764705882"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1413452.6134064868"/>
 </objectiveValues>
</CPLEXSolution>
