<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__67890.mps"
   objectiveValue="-1467436.4485039471"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1247"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.1827872842550278e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="149340.54584899399"
   maxSlack="1"
   maxRedCost="150155.79636438561"
   kappa="6853"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1467436.4485039467"/>
 </objectiveValues>
</CPLEXSolution>
