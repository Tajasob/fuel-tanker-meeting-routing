<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__78901.mps"
   objectiveValue="-429060.52843418613"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="0"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95865.427524928455"
   maxSlack="1"
   maxRedCost="50274.665700492209"
   kappa="8.3999999999999986"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-429060.52843418613"/>
 </objectiveValues>
</CPLEXSolution>
