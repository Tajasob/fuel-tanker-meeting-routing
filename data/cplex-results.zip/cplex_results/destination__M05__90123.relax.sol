<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__90123.mps"
   objectiveValue="-913177.48804067285"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="27"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95486.962883206754"
   maxSlack="1"
   maxRedCost="99966.660110370416"
   kappa="47.222222222222221"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-913177.48804067285"/>
 </objectiveValues>
</CPLEXSolution>
