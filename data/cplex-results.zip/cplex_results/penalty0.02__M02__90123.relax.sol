<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__90123.mps"
   objectiveValue="-1416.7966292424435"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="1446"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.5474735088646412e-13"
   maxPrimalResidual="0"
   maxDualResidual="2.2737367544323206e-13"
   maxX="1"
   maxPi="3880.799992027753"
   maxSlack="1"
   maxRedCost="4337.7567806707611"
   kappa="147924.90909090909"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1416.7966292424435"/>
 </objectiveValues>
</CPLEXSolution>
