<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-877252.89678800153"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1179"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x4" index="4" value="1"/>
  <variable name="x1513" index="1513" value="1"/>
  <variable name="x2055" index="2055" value="1"/>
  <variable name="x4218" index="4218" value="1"/>
  <variable name="x6297" index="6297" value="1"/>
  <variable name="x6607" index="6607" value="1"/>
  <variable name="x59058" index="59058" value="1"/>
  <variable name="x78850" index="78850" value="1"/>
  <variable name="x79502" index="79502" value="1"/>
  <variable name="x179973" index="179973" value="1"/>
  <variable name="x192053" index="192053" value="1"/>
  <variable name="x195439" index="195439" value="1"/>
  <variable name="x244285" index="244285" value="1"/>
  <variable name="x250277" index="250277" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-877252.89678800153"/>
 </objectiveValues>
</CPLEXSolution>
