<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-716000.20113406866"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x7" index="7" value="1"/>
  <variable name="x12" index="12" value="1"/>
  <variable name="x16" index="16" value="1"/>
  <variable name="x21" index="21" value="1"/>
  <variable name="x33" index="33" value="1"/>
  <variable name="x35" index="35" value="1"/>
  <variable name="x45" index="45" value="1"/>
  <variable name="x55" index="55" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-716000.20113406866"/>
 </objectiveValues>
</CPLEXSolution>
