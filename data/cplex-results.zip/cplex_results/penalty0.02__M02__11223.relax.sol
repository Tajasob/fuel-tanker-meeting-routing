<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__11223.mps"
   objectiveValue="-2866.5548477377893"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2550"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="9.0949470177292824e-13"
   maxPrimalResidual="0"
   maxDualResidual="2.2737367544323206e-13"
   maxX="1"
   maxPi="3726.0368853263049"
   maxSlack="1"
   maxRedCost="4056.5862239971912"
   kappa="110298.53333333333"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-2866.5548477377893"/>
 </objectiveValues>
</CPLEXSolution>
