<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__67890.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-676430.2113801894"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="14"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x17" index="17" value="1"/>
  <variable name="x32" index="32" value="1"/>
  <variable name="x46" index="46" value="1"/>
  <variable name="x82" index="82" value="1"/>
  <variable name="x92" index="92" value="1"/>
  <variable name="x94" index="94" value="1"/>
  <variable name="x96" index="96" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-676430.2113801894"/>
 </objectiveValues>
</CPLEXSolution>
