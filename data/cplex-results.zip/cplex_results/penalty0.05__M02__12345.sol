<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__12345.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-27212.736086651355"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2530"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1793" index="1793" value="1"/>
  <variable name="x3011" index="3011" value="1"/>
  <variable name="x4820" index="4820" value="1"/>
  <variable name="x6883" index="6883" value="1"/>
  <variable name="x9720" index="9720" value="1"/>
  <variable name="x60847" index="60847" value="1"/>
  <variable name="x469440" index="469440" value="1"/>
  <variable name="x583068" index="583068" value="1"/>
  <variable name="x674239" index="674239" value="1"/>
  <variable name="x821830" index="821830" value="1"/>
  <variable name="x822442" index="822442" value="1"/>
  <variable name="x877365" index="877365" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-27212.736086651355"/>
 </objectiveValues>
</CPLEXSolution>
