<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__12345.mps"
   objectiveValue="-977231.29583446961"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="6434"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.3655745685100555e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145692.52290456783"
   maxSlack="1"
   maxRedCost="100680.77973056471"
   kappa="278922"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-977231.29583446961"/>
 </objectiveValues>
</CPLEXSolution>
