<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-22280.208606158147"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1090"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x140" index="140" value="1"/>
  <variable name="x2708" index="2708" value="1"/>
  <variable name="x4979" index="4979" value="1"/>
  <variable name="x7506" index="7506" value="1"/>
  <variable name="x9599" index="9599" value="1"/>
  <variable name="x51723" index="51723" value="1"/>
  <variable name="x129459" index="129459" value="1"/>
  <variable name="x153074" index="153074" value="1"/>
  <variable name="x175591" index="175591" value="1"/>
  <variable name="x321044" index="321044" value="1"/>
  <variable name="x479477" index="479477" value="1"/>
  <variable name="x536242" index="536242" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-22280.208606158147"/>
 </objectiveValues>
</CPLEXSolution>
