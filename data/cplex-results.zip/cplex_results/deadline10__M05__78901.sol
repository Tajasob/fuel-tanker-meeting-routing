<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1312826.2072124092"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="39"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x449" index="449" value="1"/>
  <variable name="x2346" index="2346" value="1"/>
  <variable name="x5092" index="5092" value="1"/>
  <variable name="x7036" index="7036" value="1"/>
  <variable name="x9531" index="9531" value="1"/>
  <variable name="x12909" index="12909" value="1"/>
  <variable name="x14474" index="14474" value="1"/>
  <variable name="x15979" index="15979" value="1"/>
  <variable name="x71095" index="71095" value="1"/>
  <variable name="x141646" index="141646" value="1"/>
  <variable name="x228474" index="228474" value="1"/>
  <variable name="x453213" index="453213" value="1"/>
  <variable name="x478917" index="478917" value="1"/>
  <variable name="x485148" index="485148" value="1"/>
  <variable name="x550520" index="550520" value="1"/>
  <variable name="x552575" index="552575" value="1"/>
  <variable name="x731564" index="731564" value="1"/>
  <variable name="x829507" index="829507" value="1"/>
  <variable name="x923741" index="923741" value="1"/>
  <variable name="x1045893" index="1045893" value="1"/>
  <variable name="x1119106" index="1119106" value="1"/>
  <variable name="x1146779" index="1146779" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1312826.2072124092"/>
 </objectiveValues>
</CPLEXSolution>
