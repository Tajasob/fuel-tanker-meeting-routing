<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__11223.mps"
   objectiveValue="-977434.23242071387"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="5800"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="8.7311491370201111e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="149671.29943946557"
   maxSlack="1"
   maxRedCost="150255.77899613188"
   kappa="585215.81395348837"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-977434.23242071376"/>
 </objectiveValues>
</CPLEXSolution>
