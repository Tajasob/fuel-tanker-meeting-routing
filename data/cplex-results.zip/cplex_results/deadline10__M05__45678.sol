<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1463714.8596241907"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="5368"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x577" index="577" value="1"/>
  <variable name="x3265" index="3265" value="1"/>
  <variable name="x5501" index="5501" value="1"/>
  <variable name="x7988" index="7988" value="1"/>
  <variable name="x11767" index="11767" value="1"/>
  <variable name="x16286" index="16286" value="1"/>
  <variable name="x17858" index="17858" value="1"/>
  <variable name="x22621" index="22621" value="1"/>
  <variable name="x77543" index="77543" value="1"/>
  <variable name="x609025" index="609025" value="1"/>
  <variable name="x640742" index="640742" value="1"/>
  <variable name="x791913" index="791913" value="1"/>
  <variable name="x880868" index="880868" value="1"/>
  <variable name="x948105" index="948105" value="1"/>
  <variable name="x1123547" index="1123547" value="1"/>
  <variable name="x1184631" index="1184631" value="1"/>
  <variable name="x1223281" index="1223281" value="1"/>
  <variable name="x1665499" index="1665499" value="1"/>
  <variable name="x1961117" index="1961117" value="1"/>
  <variable name="x1986567" index="1986567" value="1"/>
  <variable name="x1997984" index="1997984" value="1"/>
  <variable name="x2017165" index="2017165" value="1"/>
  <variable name="x2070879" index="2070879" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1463714.8596241907"/>
 </objectiveValues>
</CPLEXSolution>
