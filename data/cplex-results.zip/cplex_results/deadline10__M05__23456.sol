<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1214037.0238708535"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="3081"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x617" index="617" value="1"/>
  <variable name="x1945" index="1945" value="1"/>
  <variable name="x3109" index="3109" value="1"/>
  <variable name="x3995" index="3995" value="1"/>
  <variable name="x8108" index="8108" value="1"/>
  <variable name="x12855" index="12855" value="1"/>
  <variable name="x13962" index="13962" value="1"/>
  <variable name="x15164" index="15164" value="1"/>
  <variable name="x48366" index="48366" value="1"/>
  <variable name="x53273" index="53273" value="1"/>
  <variable name="x85528" index="85528" value="1"/>
  <variable name="x430562" index="430562" value="1"/>
  <variable name="x603061" index="603061" value="1"/>
  <variable name="x627592" index="627592" value="1"/>
  <variable name="x631639" index="631639" value="1"/>
  <variable name="x862559" index="862559" value="1"/>
  <variable name="x883125" index="883125" value="1"/>
  <variable name="x903201" index="903201" value="1"/>
  <variable name="x1010136" index="1010136" value="1"/>
  <variable name="x1101452" index="1101452" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1214037.0238708532"/>
 </objectiveValues>
</CPLEXSolution>
