<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-716270.58137813001"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x0" index="0" value="1"/>
  <variable name="x5" index="5" value="1"/>
  <variable name="x17" index="17" value="1"/>
  <variable name="x21" index="21" value="1"/>
  <variable name="x36" index="36" value="1"/>
  <variable name="x43" index="43" value="1"/>
  <variable name="x52" index="52" value="1"/>
  <variable name="x58" index="58" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-716270.58137813001"/>
 </objectiveValues>
</CPLEXSolution>
