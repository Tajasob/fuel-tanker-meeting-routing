<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-2866.5548477377893"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2352"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x4915" index="4915" value="1"/>
  <variable name="x9232" index="9232" value="1"/>
  <variable name="x237561" index="237561" value="1"/>
  <variable name="x362554" index="362554" value="1"/>
  <variable name="x502874" index="502874" value="1"/>
  <variable name="x720866" index="720866" value="1"/>
  <variable name="x938898" index="938898" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-2866.5548477377893"/>
 </objectiveValues>
</CPLEXSolution>
