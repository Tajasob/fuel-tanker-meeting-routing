<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-666356.84858603694"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1" index="1" value="1"/>
  <variable name="x5" index="5" value="1"/>
  <variable name="x15" index="15" value="1"/>
  <variable name="x24" index="24" value="1"/>
  <variable name="x37" index="37" value="1"/>
  <variable name="x43" index="43" value="1"/>
  <variable name="x47" index="47" value="1"/>
  <variable name="x51" index="51" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-666356.84858603694"/>
 </objectiveValues>
</CPLEXSolution>
