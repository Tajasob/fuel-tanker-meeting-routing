<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/earliest__M05__90123.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-665794.86906332429"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="0"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x16" index="16" value="1"/>
  <variable name="x22" index="22" value="1"/>
  <variable name="x28" index="28" value="1"/>
  <variable name="x44" index="44" value="1"/>
  <variable name="x47" index="47" value="1"/>
  <variable name="x51" index="51" value="1"/>
  <variable name="x56" index="56" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-665794.86906332429"/>
 </objectiveValues>
</CPLEXSolution>
