<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__45678.mps"
   objectiveValue="-902176.00937830587"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="5314"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="4.3655745685100555e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145456.44425833586"
   maxSlack="1"
   maxRedCost="125168.78791547692"
   kappa="324045.5"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-902176.00937830587"/>
 </objectiveValues>
</CPLEXSolution>
