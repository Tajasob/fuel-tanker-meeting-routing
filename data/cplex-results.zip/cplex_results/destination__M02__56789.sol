<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-626961.16954397247"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="5"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x11" index="11" value="1"/>
  <variable name="x33" index="33" value="1"/>
  <variable name="x42" index="42" value="1"/>
  <variable name="x55" index="55" value="1"/>
  <variable name="x75" index="75" value="1"/>
  <variable name="x98" index="98" value="1"/>
  <variable name="x100" index="100" value="1"/>
  <variable name="x102" index="102" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-626961.16954397247"/>
 </objectiveValues>
</CPLEXSolution>
