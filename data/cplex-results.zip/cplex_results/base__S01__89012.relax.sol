<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S01__89012.mps"
   objectiveValue="-241087.26104051323"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="8"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="0"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="99883.941119892115"
   maxSlack="1"
   maxRedCost="100157.32715646633"
   kappa="17.333333333333332"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-241087.26104051323"/>
 </objectiveValues>
</CPLEXSolution>
