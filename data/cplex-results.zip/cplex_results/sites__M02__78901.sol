<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-876767.32419440686"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="535"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x88" index="88" value="1"/>
  <variable name="x206" index="206" value="1"/>
  <variable name="x676" index="676" value="1"/>
  <variable name="x1094" index="1094" value="1"/>
  <variable name="x1546" index="1546" value="1"/>
  <variable name="x1716" index="1716" value="1"/>
  <variable name="x2123" index="2123" value="1"/>
  <variable name="x6775" index="6775" value="1"/>
  <variable name="x7712" index="7712" value="1"/>
  <variable name="x15627" index="15627" value="1"/>
  <variable name="x16537" index="16537" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-876767.32419440674"/>
 </objectiveValues>
</CPLEXSolution>
