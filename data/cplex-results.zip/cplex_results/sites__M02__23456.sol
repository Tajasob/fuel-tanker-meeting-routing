<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__23456.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-776925.0868776819"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="209"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x0" index="0" value="1"/>
  <variable name="x336" index="336" value="1"/>
  <variable name="x566" index="566" value="1"/>
  <variable name="x898" index="898" value="1"/>
  <variable name="x1197" index="1197" value="1"/>
  <variable name="x2064" index="2064" value="1"/>
  <variable name="x4582" index="4582" value="1"/>
  <variable name="x5568" index="5568" value="1"/>
  <variable name="x5581" index="5581" value="1"/>
  <variable name="x5844" index="5844" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-776925.0868776819"/>
 </objectiveValues>
</CPLEXSolution>
