<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M05__34567.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1261601.6707447148"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="40"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x26" index="26" value="1"/>
  <variable name="x37" index="37" value="1"/>
  <variable name="x69" index="69" value="1"/>
  <variable name="x85" index="85" value="1"/>
  <variable name="x136" index="136" value="1"/>
  <variable name="x183" index="183" value="1"/>
  <variable name="x213" index="213" value="1"/>
  <variable name="x253" index="253" value="1"/>
  <variable name="x258" index="258" value="1"/>
  <variable name="x264" index="264" value="1"/>
  <variable name="x267" index="267" value="1"/>
  <variable name="x269" index="269" value="1"/>
  <variable name="x275" index="275" value="1"/>
  <variable name="x284" index="284" value="1"/>
  <variable name="x291" index="291" value="1"/>
  <variable name="x293" index="293" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1261601.6707447148"/>
 </objectiveValues>
</CPLEXSolution>
