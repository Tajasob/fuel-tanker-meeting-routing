<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M02__34567.mps"
   objectiveValue="-776118.12093501887"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="408"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="145208.61622345488"
   maxSlack="1"
   maxRedCost="100272.31533778472"
   kappa="3820.3846153846157"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-776118.12093501864"/>
 </objectiveValues>
</CPLEXSolution>
