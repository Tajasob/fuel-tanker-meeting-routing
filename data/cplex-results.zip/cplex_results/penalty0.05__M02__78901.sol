<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-26875.611165736198"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="41"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x896" index="896" value="1"/>
  <variable name="x1200" index="1200" value="1"/>
  <variable name="x5084" index="5084" value="1"/>
  <variable name="x8908" index="8908" value="1"/>
  <variable name="x12218" index="12218" value="1"/>
  <variable name="x17837" index="17837" value="1"/>
  <variable name="x122890" index="122890" value="1"/>
  <variable name="x159461" index="159461" value="1"/>
  <variable name="x294899" index="294899" value="1"/>
  <variable name="x529616" index="529616" value="1"/>
  <variable name="x667030" index="667030" value="1"/>
  <variable name="x787324" index="787324" value="1"/>
  <variable name="x840210" index="840210" value="1"/>
  <variable name="x841273" index="841273" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-26875.611165736198"/>
 </objectiveValues>
</CPLEXSolution>
