<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__45678.mps"
   objectiveValue="-777491.9859550657"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="6276"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.1827872842550278e-11"
   maxPrimalResidual="0"
   maxDualResidual="1.4551915228366852e-11"
   maxX="1"
   maxPi="145191.2280780272"
   maxSlack="1"
   maxRedCost="149884.3229086971"
   kappa="120670.15999999999"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-777491.98595506581"/>
 </objectiveValues>
</CPLEXSolution>
