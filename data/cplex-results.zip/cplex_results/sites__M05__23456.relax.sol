<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/sites__M05__23456.mps"
   objectiveValue="-1262952.1869480996"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="600"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="195290.18259886419"
   maxSlack="1"
   maxRedCost="199967.88976972975"
   kappa="25372.200000000001"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1262952.1869480996"/>
 </objectiveValues>
</CPLEXSolution>
