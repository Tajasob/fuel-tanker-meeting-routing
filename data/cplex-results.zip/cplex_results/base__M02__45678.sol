<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M02__45678.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-877399.33413922274"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="2309"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1077" index="1077" value="1"/>
  <variable name="x3043" index="3043" value="1"/>
  <variable name="x3644" index="3644" value="1"/>
  <variable name="x6874" index="6874" value="1"/>
  <variable name="x9932" index="9932" value="1"/>
  <variable name="x101435" index="101435" value="1"/>
  <variable name="x237302" index="237302" value="1"/>
  <variable name="x261835" index="261835" value="1"/>
  <variable name="x446123" index="446123" value="1"/>
  <variable name="x451497" index="451497" value="1"/>
  <variable name="x500435" index="500435" value="1"/>
  <variable name="x543840" index="543840" value="1"/>
  <variable name="x584250" index="584250" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-877399.33413922274"/>
 </objectiveValues>
</CPLEXSolution>
