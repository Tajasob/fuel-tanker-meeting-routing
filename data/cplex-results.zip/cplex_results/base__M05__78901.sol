<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__M05__78901.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1713326.1084987659"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="711"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x579" index="579" value="1"/>
  <variable name="x4768" index="4768" value="1"/>
  <variable name="x6936" index="6936" value="1"/>
  <variable name="x11993" index="11993" value="1"/>
  <variable name="x17893" index="17893" value="1"/>
  <variable name="x20846" index="20846" value="1"/>
  <variable name="x23151" index="23151" value="1"/>
  <variable name="x25861" index="25861" value="1"/>
  <variable name="x101852" index="101852" value="1"/>
  <variable name="x203063" index="203063" value="1"/>
  <variable name="x225844" index="225844" value="1"/>
  <variable name="x281375" index="281375" value="1"/>
  <variable name="x482326" index="482326" value="1"/>
  <variable name="x563032" index="563032" value="1"/>
  <variable name="x1443533" index="1443533" value="1"/>
  <variable name="x1562349" index="1562349" value="1"/>
  <variable name="x1941039" index="1941039" value="1"/>
  <variable name="x2041357" index="2041357" value="1"/>
  <variable name="x2453760" index="2453760" value="1"/>
  <variable name="x2660921" index="2660921" value="1"/>
  <variable name="x2717254" index="2717254" value="1"/>
  <variable name="x2932971" index="2932971" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1713326.1084987659"/>
 </objectiveValues>
</CPLEXSolution>
