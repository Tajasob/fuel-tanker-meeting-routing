<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/base__S03__78901.mps"
   objectiveValue="-241058.50715521426"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="dual"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="69"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.4551915228366852e-11"
   maxPrimalResidual="0"
   maxDualResidual="0"
   maxX="1"
   maxPi="95753.530333952091"
   maxSlack="1"
   maxRedCost="100231.80316620611"
   kappa="2743"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-241058.50715521423"/>
 </objectiveValues>
</CPLEXSolution>
