<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.05__M02__23456.mps"
   objectiveValue="-32152.788613661462"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2327"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="9.0949470177292824e-13"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="7406.0005187593915"
   maxSlack="1"
   maxRedCost="10158.882399685595"
   kappa="70975.555555555547"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-32152.788613661472"/>
 </objectiveValues>
</CPLEXSolution>
