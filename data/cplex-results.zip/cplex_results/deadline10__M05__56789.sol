<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__56789.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-1413898.4093412524"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="5115"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x2889" index="2889" value="1"/>
  <variable name="x4184" index="4184" value="1"/>
  <variable name="x7437" index="7437" value="1"/>
  <variable name="x9411" index="9411" value="1"/>
  <variable name="x17093" index="17093" value="1"/>
  <variable name="x19349" index="19349" value="1"/>
  <variable name="x20589" index="20589" value="1"/>
  <variable name="x23558" index="23558" value="1"/>
  <variable name="x190445" index="190445" value="1"/>
  <variable name="x316965" index="316965" value="1"/>
  <variable name="x443964" index="443964" value="1"/>
  <variable name="x468881" index="468881" value="1"/>
  <variable name="x510282" index="510282" value="1"/>
  <variable name="x548554" index="548554" value="1"/>
  <variable name="x937270" index="937270" value="1"/>
  <variable name="x974052" index="974052" value="1"/>
  <variable name="x994962" index="994962" value="1"/>
  <variable name="x1105363" index="1105363" value="1"/>
  <variable name="x1276769" index="1276769" value="1"/>
  <variable name="x1335353" index="1335353" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-1413898.4093412524"/>
 </objectiveValues>
</CPLEXSolution>
