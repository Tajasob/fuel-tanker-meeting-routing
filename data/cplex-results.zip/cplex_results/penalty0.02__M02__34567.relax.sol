<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/penalty0.02__M02__34567.mps"
   objectiveValue="-2461.7728492380265"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="2726"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="1.1368683772161603e-12"
   maxPrimalResidual="0"
   maxDualResidual="4.5474735088646412e-13"
   maxX="1"
   maxPi="4007.966457517874"
   maxSlack="1"
   maxRedCost="5044.7485238562513"
   kappa="282200.14285714284"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-2461.7728492380265"/>
 </objectiveValues>
</CPLEXSolution>
