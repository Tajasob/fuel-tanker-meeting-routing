<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__12345.mps"
   objectiveValue="-727364.57926163683"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="327"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="195141.08496774812"
   maxSlack="1"
   maxRedCost="150032.67233361665"
   kappa="123783.42857142857"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-727364.57926163683"/>
 </objectiveValues>
</CPLEXSolution>
