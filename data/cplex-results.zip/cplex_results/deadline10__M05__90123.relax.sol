<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M05__90123.mps"
   objectiveValue="-1414053.4739011081"
   solutionTypeValue="1"
   solutionTypeString="basic"
   solutionStatusValue="1"
   solutionStatusString="optimal"
   solutionMethodString="primal"
   primalFeasible="1"
   dualFeasible="1"
   simplexIterations="18648"
   writeLevel="4"/>
 <quality
   epRHS="9.9999999999999995e-07"
   epOpt="9.9999999999999995e-07"
   maxPrimalInfeas="0"
   maxDualInfeas="2.9103830456733704e-11"
   maxPrimalResidual="0"
   maxDualResidual="2.9103830456733704e-11"
   maxX="1"
   maxPi="145492.51562733116"
   maxSlack="1"
   maxRedCost="150215.25498258372"
   kappa="275122.56896551722"/>
 <objectiveValues>
  <objective index="0" name="obj" value="-1414053.4739011079"/>
 </objectiveValues>
</CPLEXSolution>
