<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/destination__M02__11223.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-726382.47382479301"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="28"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x3" index="3" value="1"/>
  <variable name="x40" index="40" value="1"/>
  <variable name="x42" index="42" value="1"/>
  <variable name="x72" index="72" value="1"/>
  <variable name="x75" index="75" value="1"/>
  <variable name="x101" index="101" value="1"/>
  <variable name="x106" index="106" value="1"/>
  <variable name="x116" index="116" value="1"/>
  <variable name="x118" index="118" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-726382.47382479301"/>
 </objectiveValues>
</CPLEXSolution>
