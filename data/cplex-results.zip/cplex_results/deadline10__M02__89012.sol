<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>
<CPLEXSolution version="1.2">
 <header
   problemName="/tmp/p1_cplex/deadline10__M02__89012.mps"
   solutionName="incumbent"
   solutionIndex="-1"
   objectiveValue="-727563.31319674745"
   solutionTypeValue="3"
   solutionTypeString="primal"
   solutionStatusValue="101"
   solutionStatusString="integer optimal solution"
   solutionMethodString="mip"
   primalFeasible="1"
   dualFeasible="1"
   MIPNodes="0"
   MIPIterations="1385"
   writeLevel="4"/>
 <quality
   epInt="1.0000000000000001e-05"
   epRHS="9.9999999999999995e-07"
   maxIntInfeas="0"
   maxPrimalInfeas="0"
   maxX="1"
   maxSlack="1"/>
 <variables>
  <variable name="x1024" index="1024" value="1"/>
  <variable name="x2044" index="2044" value="1"/>
  <variable name="x3637" index="3637" value="1"/>
  <variable name="x5361" index="5361" value="1"/>
  <variable name="x6571" index="6571" value="1"/>
  <variable name="x105526" index="105526" value="1"/>
  <variable name="x110218" index="110218" value="1"/>
  <variable name="x220079" index="220079" value="1"/>
  <variable name="x282358" index="282358" value="1"/>
  <variable name="x292441" index="292441" value="1"/>
  <variable name="x438559" index="438559" value="1"/>
  <variable name="x551827" index="551827" value="1"/>
 </variables>
 <objectiveValues>
  <objective index="0" name="obj" value="-727563.31319674745"/>
 </objectiveValues>
</CPLEXSolution>
